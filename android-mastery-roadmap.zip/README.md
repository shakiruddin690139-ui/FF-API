# NEXA AI — Advanced Personal Android AI Assistant

NEXA AI is a personal AI assistant built for Android using Kotlin and Jetpack Compose. It features a soft 3D neumorphic aesthetic, multi-provider AI support (Grok by xAI, OpenAI ChatGPT, and Google Gemini), voice recognition and synthesis, natural language device action execution, and an AI-assisted video creation studio.

---

## Key Highlights

- **Multi-Provider Architecture**:
  - **Grok (xAI)**: `grok-2-latest`, `grok-beta` via official xAI endpoints with streaming.
  - **OpenAI (ChatGPT)**: `gpt-4o-mini`, `gpt-4o`, `gpt-4-turbo` via official OpenAI API.
  - **Google Gemini**: `gemini-2.5-flash`, `gemini-1.5-pro` with multimodal vision and SSE streaming.
- **Strict No-Developer-Backend**:
  - No developer-owned custom servers or mandatory cloud accounts.
  - All chats and projects persist locally in Room database (`nexa_ai_local.db`).
  - API keys are encrypted on-device via **Android KeyStore** (AES-256-GCM) with no plaintext leaks or logging.
- **Natural Language Device Commands**:
  - App launching (YouTube, Chrome, Calculator, Camera, Settings).
  - Web navigation and Google Search.
  - YouTube search and playback shortcuts.
  - Media volume and playback control.
  - Optional Accessibility Service for user-authorized UI assistance.
- **Voice Assistant**:
  - Android `SpeechRecognizer` for English & Hindi speech-to-text.
  - Android `TextToSpeech` engine with adjustable playback rates.
  - Dynamic 3D pulsating energy visualizer canvas.
  - Optional continuous voice foreground service (`ContinuousVoiceService`).
- **AI Video Creation Studio**:
  - 9:16 Shorts/Reels, 16:9 Landscape, and 1:1 Square aspect ratios.
  - Text animation presets: Pop, Typewriter, Word-by-Word, Slide Up, Fade In, Bounce, Scale In.
  - AI script generator powered by the active AI provider.
  - Real local frame rendering and Android Sharesheet integration.
- **Permissions Center**:
  - Real-time status for Microphone, Internet, Notifications, and Accessibility services.

---

## Visual Design Reference

- **Color Palette**:
  - Primary Background: `#F2F6FF`
  - Secondary Background: `#E7EEFC`
  - Surface White: `#FFFFFF`
  - Ice Blue: `#DCE8FF`
  - Primary Blue: `#1769FF`
  - Electric Blue: `#3188FF`
  - Royal Blue: `#263FE8`
  - Dark Navy: `#101A3C`
  - Success: `#18A878` | Warning: `#F4A62A` | Error: `#E5484D`
- **Theme**: Cohesive Soft Neumorphism with frosted-glass card surfaces, custom adaptive launcher icon, and dark navy mode.

---

## API Key Setup

1. Open **Settings** in the bottom navigation bar.
2. Under **AI Provider & Models**, locate **Grok**, **OpenAI**, or **Google Gemini**.
3. Tap **Configure**, input your API key, and tap **Save Securely**.
4. Tap **Test Ping** to verify connectivity directly against the provider.
5. If using Google AI Studio with `GEMINI_API_KEY`, Gemini connects seamlessly.

---

## Build & Test Instructions

### Compilation
```bash
gradle assembleDebug
```

### Running Unit & Robolectric Tests
```bash
gradle :app:testDebugUnitTest
```
