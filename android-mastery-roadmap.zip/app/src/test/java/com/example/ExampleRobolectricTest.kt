package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.automation.commands.ActionExecutor
import com.example.automation.commands.DeviceAction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun readStringFromContext() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("NEXA AI", appName)
    }

    @Test
    fun testActionExecutorCopyText() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val executor = ActionExecutor(context)
        val result = executor.execute(DeviceAction.CopyText("Hello from NEXA AI"))
        assertTrue(result.isSuccess)
    }
}
