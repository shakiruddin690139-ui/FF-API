package com.example

import com.example.ai.model.AiProviderType
import com.example.automation.commands.ActionInterpreter
import com.example.automation.commands.DeviceAction
import com.example.automation.commands.MediaCommand
import com.example.automation.commands.SettingType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NexaUnitTest {

    private val interpreter = ActionInterpreter()

    @Test
    fun testYouTubeCommandInterpretation() {
        val action1 = interpreter.interpret("Open YouTube")
        assertTrue(action1 is DeviceAction.OpenApplication)
        assertEquals("YouTube", (action1 as DeviceAction.OpenApplication).appName)

        val action2 = interpreter.interpret("youtube kholo")
        assertTrue(action2 is DeviceAction.OpenApplication)

        val action3 = interpreter.interpret("search youtube for Free Fire gameplay")
        assertTrue(action3 is DeviceAction.SearchYouTube)
        assertEquals("Free Fire gameplay", (action3 as DeviceAction.SearchYouTube).query)
    }

    @Test
    fun testChromeAndBrowserCommands() {
        val actionChrome = interpreter.interpret("open chrome")
        assertTrue(actionChrome is DeviceAction.OpenApplication)
        assertEquals("com.android.chrome", (actionChrome as DeviceAction.OpenApplication).preferredPackage)

        val actionUrl = interpreter.interpret("open google.com")
        assertTrue(actionUrl is DeviceAction.OpenWebsite)
        assertEquals("https://google.com", (actionUrl as DeviceAction.OpenWebsite).url)

        val actionChatGpt = interpreter.interpret("open chatgpt in my browser")
        assertTrue(actionChatGpt is DeviceAction.OpenWebsite)
        assertEquals("https://chatgpt.com", (actionChatGpt as DeviceAction.OpenWebsite).url)
    }

    @Test
    fun testSettingsAndMediaCommands() {
        val actionBt = interpreter.interpret("open bluetooth settings")
        assertTrue(actionBt is DeviceAction.OpenSystemSettings)
        assertEquals(SettingType.BLUETOOTH, (actionBt as DeviceAction.OpenSystemSettings).settingType)

        val actionWifi = interpreter.interpret("wifi settings")
        assertTrue(actionWifi is DeviceAction.OpenSystemSettings)
        assertEquals(SettingType.WIFI, (actionWifi as DeviceAction.OpenSystemSettings).settingType)

        val actionVol = interpreter.interpret("volume up")
        assertTrue(actionVol is DeviceAction.MediaControl)
        assertEquals(MediaCommand.VOLUME_UP, (actionVol as DeviceAction.MediaControl).command)
    }

    @Test
    fun testProviderTypes() {
        assertEquals(AiProviderType.GROK, AiProviderType.fromId("grok"))
        assertEquals(AiProviderType.OPENAI, AiProviderType.fromId("OPENAI"))
        assertEquals(AiProviderType.GEMINI, AiProviderType.fromId("gemini"))
        assertTrue(AiProviderType.GROK.models.contains("grok-2-latest"))
        assertTrue(AiProviderType.OPENAI.models.contains("gpt-4o-mini"))
        assertTrue(AiProviderType.GEMINI.models.contains("gemini-2.5-flash"))
    }
}
