package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = NexaElectricBlue,
    onPrimary = NexaSurfaceWhite,
    primaryContainer = NexaRoyalBlue,
    onPrimaryContainer = NexaIceBlue,
    secondary = NexaElectricBlue,
    onSecondary = NexaSurfaceWhite,
    tertiary = NexaIceBlue,
    background = NexaDarkBackground,
    onBackground = NexaDarkText,
    surface = NexaDarkSurface,
    onSurface = NexaDarkText,
    surfaceVariant = NexaDarkSurfaceVariant,
    onSurfaceVariant = NexaDarkSecondaryText,
    outline = NexaDarkSurfaceVariant,
    error = NexaError
)

private val LightColorScheme = lightColorScheme(
    primary = NexaPrimaryBlue,
    onPrimary = NexaSurfaceWhite,
    primaryContainer = NexaIceBlue,
    onPrimaryContainer = NexaRoyalBlue,
    secondary = NexaElectricBlue,
    onSecondary = NexaSurfaceWhite,
    tertiary = NexaRoyalBlue,
    background = NexaPrimaryBackground,
    onBackground = NexaDarkNavy,
    surface = NexaSurfaceWhite,
    onSurface = NexaDarkNavy,
    surfaceVariant = NexaSecondaryBackground,
    onSurfaceVariant = NexaSecondaryText,
    outline = NexaIceBlue,
    error = NexaError
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep branded NEXA AI soft 3D blue identity
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
