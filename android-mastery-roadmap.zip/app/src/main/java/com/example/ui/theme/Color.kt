package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// NEXA AI Signature Palette (from design specification)
val NexaPrimaryBackground = Color(0xFFF2F6FF)
val NexaSecondaryBackground = Color(0xFFE7EEFC)
val NexaSurfaceWhite = Color(0xFFFFFFFF)
val NexaIceBlue = Color(0xFFDCE8FF)
val NexaPrimaryBlue = Color(0xFF1769FF)
val NexaElectricBlue = Color(0xFF3188FF)
val NexaRoyalBlue = Color(0xFF263FE8)
val NexaDarkNavy = Color(0xFF101A3C)
val NexaSecondaryText = Color(0xFF697895)
val NexaSuccess = Color(0xFF18A878)
val NexaWarning = Color(0xFFF4A62A)
val NexaError = Color(0xFFE5484D)

// Dark Mode Palette
val NexaDarkBackground = Color(0xFF0C1328)
val NexaDarkSecondaryBackground = Color(0xFF131D3B)
val NexaDarkSurface = Color(0xFF182348)
val NexaDarkSurfaceVariant = Color(0xFF22305E)
val NexaDarkText = Color(0xFFF2F6FF)
val NexaDarkSecondaryText = Color(0xFF90A1C0)

// Gradients
val NexaPrimaryGradient = Brush.linearGradient(
    colors = listOf(NexaElectricBlue, NexaRoyalBlue)
)

val NexaAccentGlowGradient = Brush.radialGradient(
    colors = listOf(NexaElectricBlue.copy(alpha = 0.35f), Color.Transparent)
)

val NexaIceCardGradient = Brush.verticalGradient(
    colors = listOf(NexaSurfaceWhite, NexaIceBlue.copy(alpha = 0.5f))
)
