package com.example.ui.settings

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.model.AiProviderType
import com.example.automation.accessibility.NexaAccessibilityService
import com.example.core.navigation.Screen
import com.example.ui.NexaViewModel
import com.example.ui.theme.NexaDarkNavy
import com.example.ui.theme.NexaElectricBlue
import com.example.ui.theme.NexaError
import com.example.ui.theme.NexaIceBlue
import com.example.ui.theme.NexaPrimaryBlue
import com.example.ui.theme.NexaPrimaryGradient
import com.example.ui.theme.NexaRoyalBlue
import com.example.ui.theme.NexaSecondaryBackground
import com.example.ui.theme.NexaSuccess
import com.example.ui.theme.nexaCard
import com.example.ui.theme.nexaGlowButton

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: NexaViewModel,
    onNavigateToPermissions: () -> Unit
) {
    val context = LocalContext.current
    val selectedProviderStr by viewModel.selectedProviderFlow.collectAsState()
    val activeProvider = AiProviderType.fromId(selectedProviderStr)
    val voiceLanguage by viewModel.voiceLanguageFlow.collectAsState()
    val speechSpeed by viewModel.speechSpeedFlow.collectAsState()
    val continuousListening by viewModel.continuousListeningFlow.collectAsState()
    val autoSpeakResponse by viewModel.autoSpeakResponseFlow.collectAsState()
    val darkTheme by viewModel.darkThemeFlow.collectAsState()
    val followSystemTheme by viewModel.followSystemThemeFlow.collectAsState()
    val isTestingApi by viewModel.isTestingApi.collectAsState()
    val testResults by viewModel.testResults.collectAsState()

    var showApiKeyDialogFor by remember { mutableStateOf<AiProviderType?>(null) }
    var apiKeyInputText by remember { mutableStateOf("") }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    val isAccessibilityEnabled = remember { NexaAccessibilityService.isAccessibilityEnabled(context) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Settings & AI Configuration",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Manage AI providers, encrypted keys, voice parameters, and permissions",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Section 1: AI Provider & Model Configuration
        item {
            SettingsSectionHeader(title = "AI PROVIDER & MODELS", icon = Icons.Default.Key)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .nexaCard(elevation = 2.dp)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Provider selection
                Text(
                    text = "Active AI Intelligence Provider",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AiProviderType.entries.forEach { p ->
                        val isSelected = p == activeProvider
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .then(
                                    if (isSelected) Modifier.background(NexaPrimaryGradient)
                                    else Modifier.background(NexaSecondaryBackground)
                                )
                                .clickable { viewModel.setSelectedProvider(p) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = p.displayName.substringBefore(" "),
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Model Selection Dropdown for active provider
                var expanded by remember { mutableStateOf(false) }
                val currentModel = viewModel.getModelForProvider(activeProvider)

                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = currentModel,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Model Identifier") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NexaElectricBlue,
                            unfocusedBorderColor = NexaIceBlue
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        activeProvider.models.forEach { modelOption ->
                            DropdownMenuItem(
                                text = { Text(modelOption) },
                                onClick = {
                                    viewModel.setModelForProvider(activeProvider, modelOption)
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                // Encrypted API Key Config Cards for all 3 providers
                AiProviderType.entries.forEach { p ->
                    val hasKey = viewModel.hasApiKey(p)
                    val masked = viewModel.getMaskedApiKey(p)
                    val testStatus = testResults[p]

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(NexaSecondaryBackground.copy(alpha = 0.5f))
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = p.displayName,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (hasKey) "Key: $masked" else "Key not set",
                                    fontSize = 11.sp,
                                    color = if (hasKey) NexaSuccess else NexaError
                                )
                            }

                            Row {
                                TextButton(
                                    onClick = {
                                        showApiKeyDialogFor = p
                                        apiKeyInputText = ""
                                    }
                                ) {
                                    Text("Configure", fontSize = 12.sp, color = NexaPrimaryBlue)
                                }
                                TextButton(
                                    onClick = { viewModel.testProviderConnectivity(p) }
                                ) {
                                    Text("Test Ping", fontSize = 12.sp, color = NexaRoyalBlue)
                                }
                            }
                        }

                        if (testStatus != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = testStatus,
                                fontSize = 11.sp,
                                color = if (testStatus.startsWith("Success")) NexaSuccess else NexaError
                            )
                        }
                    }
                }
            }
        }

        // Section 2: Voice & Audio Settings
        item {
            SettingsSectionHeader(title = "VOICE & SPEECH RECOGNITION", icon = Icons.Default.Mic)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .nexaCard(elevation = 2.dp)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Language Selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Voice Assistant Language", fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("en-US" to "English", "hi-IN" to "हिंदी").forEach { (code, label) ->
                            val isSel = voiceLanguage == code
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSel) NexaPrimaryBlue else NexaSecondaryBackground)
                                    .clickable { viewModel.setVoiceLanguage(code) }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                // Speech Speed Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Speech Rate (TTS)", fontSize = 14.sp)
                        Text(text = "%.1fx".format(speechSpeed), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = NexaPrimaryBlue)
                    }
                    Slider(
                        value = speechSpeed,
                        onValueChange = { viewModel.setSpeechSpeed(it) },
                        valueRange = 0.5f..2.0f,
                        steps = 5,
                        colors = SliderDefaults.colors(
                            thumbColor = NexaPrimaryBlue,
                            activeTrackColor = NexaElectricBlue
                        )
                    )
                }

                // Auto speak toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Auto-Speak AI Responses", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text(text = "Reads text aloud automatically after generation", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = autoSpeakResponse,
                        onCheckedChange = { viewModel.setAutoSpeakResponse(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = NexaPrimaryBlue)
                    )
                }

                // Continuous listening toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Continuous Listening Mode", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text(text = "Maintains authorized foreground voice session", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = continuousListening,
                        onCheckedChange = { viewModel.setContinuousListening(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = NexaPrimaryBlue)
                    )
                }
            }
        }

        // Section 3: Device Control & Accessibility
        item {
            SettingsSectionHeader(title = "DEVICE AUTOMATION & ACCESS", icon = Icons.Default.Accessibility)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .nexaCard(elevation = 2.dp)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Accessibility Service Status", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (isAccessibilityEnabled) "Authorized & Ready" else "Disabled in Android Settings",
                            fontSize = 12.sp,
                            color = if (isAccessibilityEnabled) NexaSuccess else NexaError
                        )
                    }
                    Button(
                        onClick = {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NexaPrimaryBlue),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Open Settings", fontSize = 12.sp)
                    }
                }

                // Permissions Center Shortcut
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexaIceBlue.copy(alpha = 0.5f))
                        .clickable { onNavigateToPermissions() }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = NexaRoyalBlue)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(text = "Permissions Center", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = NexaRoyalBlue)
                            Text(text = "Review all declared & granted capabilities", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = NexaRoyalBlue, modifier = Modifier.size(16.dp))
                }
            }
        }

        // Section 4: Visual Appearance & Theme
        item {
            SettingsSectionHeader(title = "APPEARANCE & THEME", icon = Icons.Default.Palette)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .nexaCard(elevation = 2.dp)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Follow System Theme", fontSize = 14.sp)
                    Switch(
                        checked = followSystemTheme,
                        onCheckedChange = { viewModel.setFollowSystemTheme(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = NexaPrimaryBlue)
                    )
                }

                if (!followSystemTheme) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Dark Navy Theme", fontSize = 14.sp)
                        Switch(
                            checked = darkTheme,
                            onCheckedChange = { viewModel.setDarkTheme(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = NexaPrimaryBlue)
                        )
                    }
                }
            }
        }

        // Section 5: Privacy & Local Data Storage
        item {
            SettingsSectionHeader(title = "PRIVACY & STORAGE", icon = Icons.Default.Storage)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .nexaCard(elevation = 2.dp)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showPrivacyDialog = true }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Privacy Architecture Disclosure", fontSize = 14.sp, color = NexaPrimaryBlue)
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = NexaPrimaryBlue, modifier = Modifier.size(16.dp))
                }
            }
        }

        // Section 6: About NEXA AI
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "NEXA AI v1.0.0",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Strict No-Developer-Backend • On-Device Keystore Encrypted",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    // Configure API Key Dialog
    if (showApiKeyDialogFor != null) {
        val provider = showApiKeyDialogFor!!
        AlertDialog(
            onDismissRequest = { showApiKeyDialogFor = null },
            title = { Text("Configure ${provider.displayName} Key") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Your API key is encrypted using Android KeyStore (AES-GCM) and stored only in private storage on your phone. It is never logged or transmitted elsewhere.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = apiKeyInputText,
                        onValueChange = { apiKeyInputText = it },
                        placeholder = { Text("Enter your API key...") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.saveApiKey(provider, apiKeyInputText.trim())
                        showApiKeyDialogFor = null
                    }
                ) {
                    Text("Save Securely", fontWeight = FontWeight.Bold, color = NexaPrimaryBlue)
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiKeyDialogFor = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Privacy Dialog
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy Architecture") },
            text = {
                Text(
                    text = "NEXA AI is designed with a strict zero-developer-backend architecture. All your conversation history, studio projects, preferences, and API credentials are kept exclusively on your local device. Remote AI requests communicate directly from your device to the selected provider (Grok, OpenAI, or Google Gemini) according to their respective privacy terms.",
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text("Close", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
private fun SettingsSectionHeader(title: String, icon: ImageVector) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = NexaPrimaryBlue,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            letterSpacing = 1.sp
        )
    }
}
