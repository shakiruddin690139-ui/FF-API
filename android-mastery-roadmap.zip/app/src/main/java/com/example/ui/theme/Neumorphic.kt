package com.example.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Soft 3D Neumorphic card styling for NEXA AI with gentle depth and ice-blue accenting.
 */
@Composable
fun Modifier.nexaCard(
    shape: Shape = RoundedCornerShape(20.dp),
    elevation: Dp = 4.dp,
    borderWidth: Dp = 1.dp,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    borderColor: Color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
): Modifier {
    return this
        .shadow(
            elevation = elevation,
            shape = shape,
            ambientColor = NexaRoyalBlue.copy(alpha = 0.08f),
            spotColor = NexaPrimaryBlue.copy(alpha = 0.12f)
        )
        .clip(shape)
        .background(containerColor)
        .border(width = borderWidth, color = borderColor, shape = shape)
}

/**
 * Gradient action pill or button with soft outer glow.
 */
@Composable
fun Modifier.nexaGlowButton(
    shape: Shape = RoundedCornerShape(16.dp),
    gradient: Brush = NexaPrimaryGradient,
    elevation: Dp = 6.dp
): Modifier {
    return this
        .shadow(
            elevation = elevation,
            shape = shape,
            ambientColor = NexaElectricBlue.copy(alpha = 0.25f),
            spotColor = NexaRoyalBlue.copy(alpha = 0.4f)
        )
        .clip(shape)
        .background(gradient)
}
