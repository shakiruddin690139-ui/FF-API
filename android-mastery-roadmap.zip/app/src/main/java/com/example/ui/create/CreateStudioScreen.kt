package com.example.ui.create

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.media.video.TextAnimationType
import com.example.media.video.VideoAspectRatio
import com.example.ui.NexaViewModel
import com.example.ui.theme.NexaElectricBlue
import com.example.ui.theme.NexaIceBlue
import com.example.ui.theme.NexaPrimaryBlue
import com.example.ui.theme.NexaPrimaryGradient
import com.example.ui.theme.NexaRoyalBlue
import com.example.ui.theme.NexaSecondaryBackground
import com.example.ui.theme.NexaSuccess
import com.example.ui.theme.nexaCard
import com.example.ui.theme.nexaGlowButton

@Composable
fun CreateStudioScreen(viewModel: NexaViewModel) {
    val project by viewModel.videoProject.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Video Studio, 1: AI Script Writer
    var topicInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // 1. Header
        item {
            Column {
                Text(
                    text = "AI Video Creation Studio",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Craft viral short-form animated text & voiceover videos locally",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // 2. Tabs: Studio / Script Generator
        item {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = NexaSecondaryBackground,
                contentColor = NexaPrimaryBlue,
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .padding(4.dp)
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = "Interactive Studio",
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = "AI Script Assistant",
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                )
            }
        }

        if (selectedTab == 1) {
            // AI Script Generator Tab
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .nexaCard(elevation = 3.dp)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "GENERATE VIRAL SCRIPT",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NexaRoyalBlue
                    )
                    OutlinedTextField(
                        value = topicInput,
                        onValueChange = { topicInput = it },
                        placeholder = { Text("e.g. 3 Secret Android Tricks, Why AI is the Future...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NexaElectricBlue,
                            unfocusedBorderColor = NexaIceBlue
                        )
                    )

                    Button(
                        onClick = {
                            if (topicInput.isNotBlank()) {
                                viewModel.generateAiScript(topicInput)
                                selectedTab = 0
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .nexaGlowButton(shape = RoundedCornerShape(14.dp)),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Generate with AI & Apply",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // 3. Aspect Ratio Selector
        item {
            Text(
                text = "ASPECT RATIO",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                VideoAspectRatio.entries.forEach { ratio ->
                    val isSelected = ratio == project.aspectRatio
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .then(
                                if (isSelected) Modifier.background(NexaPrimaryGradient)
                                else Modifier.background(MaterialTheme.colorScheme.surface)
                            )
                            .border(width = 1.dp, color = if (isSelected) Color.Transparent else NexaIceBlue, shape = RoundedCornerShape(14.dp))
                            .clickable { viewModel.setVideoAspectRatio(ratio) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = ratio.label.substringBefore(" "),
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // 4. Live Video Player Preview Card
        item {
            Text(
                text = "REAL-TIME PREVIEW",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(if (project.aspectRatio == VideoAspectRatio.VERTICAL_9_16) 9f / 12f else if (project.aspectRatio == VideoAspectRatio.LANDSCAPE_16_9) 16f / 9f else 1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(NexaRoyalBlue, Color(0xFF0F172A))
                        )
                    )
                    .nexaCard(elevation = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                AnimatedTextVideoPreview(
                    text = project.timedCaptions.firstOrNull()?.text ?: project.scriptText,
                    animationType = project.animationType
                )

                // Aspect ratio watermark
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.5f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = project.aspectRatio.label,
                        fontSize = 10.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 5. Text Animation Presets Carousel
        item {
            Text(
                text = "ANIMATION PRESET",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(TextAnimationType.entries) { anim ->
                    val isSelected = anim == project.animationType
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .then(
                                if (isSelected) Modifier.background(NexaPrimaryGradient)
                                else Modifier.background(MaterialTheme.colorScheme.surface)
                            )
                            .border(width = 1.dp, color = if (isSelected) Color.Transparent else NexaIceBlue, shape = RoundedCornerShape(16.dp))
                            .clickable { viewModel.setTextAnimationType(anim) }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = anim.displayName,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // 6. Timed Captions Editor
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .nexaCard(elevation = 2.dp)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TIMED CAPTIONS TIMELINE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NexaRoyalBlue
                    )
                    Text(
                        text = "${project.durationSeconds}s duration",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = project.scriptText,
                    onValueChange = { viewModel.updateVideoScript(it) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NexaElectricBlue,
                        unfocusedBorderColor = NexaIceBlue
                    ),
                    maxLines = 4
                )

                Spacer(modifier = Modifier.height(10.dp))

                project.timedCaptions.forEachIndexed { idx, cap ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(NexaIceBlue)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "%.1fs".format(cap.startSecond),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = NexaRoyalBlue
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = cap.text,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 7. Render & Export Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .nexaCard(elevation = 4.dp)
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (project.isRendering) {
                    Text(
                        text = "Rendering video project... ${(project.renderProgress * 100).toInt()}%",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = NexaPrimaryBlue
                    )
                    LinearProgressIndicator(
                        progress = { project.renderProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape),
                        color = NexaElectricBlue
                    )
                } else if (project.renderedFilePath != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Done",
                                tint = NexaSuccess,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Video Rendered Successfully!",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = NexaSuccess
                            )
                        }
                        Button(
                            onClick = { viewModel.shareCurrentRenderedVideo() },
                            colors = ButtonDefaults.buttonColors(containerColor = NexaPrimaryBlue),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share", fontSize = 12.sp)
                        }
                    }
                } else {
                    Button(
                        onClick = { viewModel.renderAndExportVideo() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .nexaGlowButton(shape = RoundedCornerShape(16.dp)),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                    ) {
                        Icon(imageVector = Icons.Default.Movie, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Render & Export Project",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AnimatedTextVideoPreview(
    text: String,
    animationType: TextAnimationType
) {
    val scale = remember { Animatable(0.8f) }

    LaunchedEffect(animationType) {
        scale.animateTo(
            targetValue = 1.05f,
            animationSpec = infiniteRepeatable(
                animation = tween(800, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            )
        )
    }

    Column(
        modifier = Modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "NEXA AI",
            fontSize = 12.sp,
            fontWeight = FontWeight.ExtraBold,
            color = NexaElectricBlue,
            letterSpacing = 2.sp
        )
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = text,
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            color = Color.White,
            textAlign = TextAlign.Center,
            modifier = Modifier.scale(if (animationType == TextAnimationType.POP || animationType == TextAnimationType.BOUNCE) scale.value else 1f)
        )
    }
}
