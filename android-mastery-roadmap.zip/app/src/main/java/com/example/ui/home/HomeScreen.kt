package com.example.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ai.model.AiProviderType
import com.example.core.navigation.Screen
import com.example.ui.NexaViewModel
import com.example.ui.theme.NexaElectricBlue
import com.example.ui.theme.NexaIceBlue
import com.example.ui.theme.NexaPrimaryBlue
import com.example.ui.theme.NexaPrimaryGradient
import com.example.ui.theme.NexaRoyalBlue
import com.example.ui.theme.NexaSecondaryBackground
import com.example.ui.theme.NexaSuccess
import com.example.ui.theme.nexaCard
import com.example.ui.theme.nexaGlowButton

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: NexaViewModel,
    onNavigate: (String) -> Unit
) {
    val selectedProviderStr by viewModel.selectedProviderFlow.collectAsState()
    val activeProvider = AiProviderType.fromId(selectedProviderStr)
    val lastActionResult by viewModel.lastActionResult.collectAsState()
    val recentConversations by viewModel.conversationsFlow.collectAsState()

    var quickInputText by remember { mutableStateOf("") }

    val suggestedPrompts = listOf(
        "Open YouTube",
        "Search YouTube for Free Fire gameplay",
        "Open Chrome",
        "Create an animated text video",
        "Explain this screen",
        "Open Bluetooth settings",
        "Write a viral YouTube Short script",
        "Tell me a fun AI fact"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // 1. Header with Logo & Greeting
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .nexaCard(shape = CircleShape, elevation = 3.dp)
                            .clip(CircleShape)
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_nexa_logo),
                            contentDescription = "NEXA AI Logo",
                            modifier = Modifier.size(44.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "NEXA AI",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(NexaSuccess)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Personal Assistant Active",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                IconButton(
                    onClick = { onNavigate(Screen.Settings.route) },
                    modifier = Modifier
                        .nexaCard(shape = CircleShape, elevation = 2.dp)
                        .size(44.dp)
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = NexaPrimaryBlue
                    )
                }
            }
        }

        // 2. Provider Pill Selector
        item {
            Text(
                text = "AI INTELLIGENCE ENGINE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AiProviderType.entries.forEach { provider ->
                    val isSelected = provider == activeProvider
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .then(
                                if (isSelected) Modifier.background(NexaPrimaryGradient)
                                else Modifier.background(MaterialTheme.colorScheme.surface)
                            )
                            .clickable { viewModel.setSelectedProvider(provider) }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = provider.displayName.substringBefore(" "),
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // 3. Prominent Interaction Composer Card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .nexaCard(elevation = 6.dp)
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "How can I assist you today?",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(NexaIceBlue)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = viewModel.getModelForProvider(activeProvider),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = NexaRoyalBlue
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = quickInputText,
                    onValueChange = { quickInputText = it },
                    placeholder = {
                        Text(
                            "Ask a question or say \"Open YouTube\"...",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_input_field"),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NexaElectricBlue,
                        unfocusedBorderColor = NexaIceBlue,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    maxLines = 3
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Voice shortcut
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(NexaSecondaryBackground)
                            .clickable { onNavigate(Screen.Voice.route) }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voice Mode",
                            tint = NexaPrimaryBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Voice Mode",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NexaPrimaryBlue
                        )
                    }

                    // Send Button
                    Box(
                        modifier = Modifier
                            .nexaGlowButton(shape = RoundedCornerShape(14.dp), elevation = 4.dp)
                            .clickable {
                                if (quickInputText.isNotBlank()) {
                                    val textToSend = quickInputText
                                    quickInputText = ""
                                    viewModel.sendMessage(textToSend) {
                                        onNavigate(Screen.Chat.route)
                                    }
                                }
                            }
                            .padding(horizontal = 20.dp, vertical = 10.dp)
                            .testTag("home_send_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Ask NEXA",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        // 4. Last Executed Action Banner (if active)
        if (lastActionResult != null) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .nexaCard(containerColor = NexaIceBlue.copy(alpha = 0.7f))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "DEVICE ACTION VERIFIED",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = NexaRoyalBlue
                        )
                        Text(
                            text = lastActionResult?.feedbackMessage.orEmpty(),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    Text(
                        text = "Dismiss",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NexaPrimaryBlue,
                        modifier = Modifier
                            .clickable { viewModel.clearActionResult() }
                            .padding(6.dp)
                    )
                }
            }
        }

        // 5. Quick Action Cards (Real Workflows)
        item {
            Text(
                text = "DEVICE ACTIONS & CREATION",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = "YouTube",
                    subtitle = "Search & Play",
                    icon = Icons.Default.SmartDisplay,
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.sendMessage("Open YouTube") { onNavigate(Screen.Chat.route) }
                }

                QuickActionCard(
                    title = "Video Studio",
                    subtitle = "AI Shorts & Text",
                    icon = Icons.Default.AutoAwesome,
                    modifier = Modifier.weight(1f)
                ) {
                    onNavigate(Screen.Create.route)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = "Voice Chat",
                    subtitle = "Continuous Mode",
                    icon = Icons.Default.Mic,
                    modifier = Modifier.weight(1f)
                ) {
                    onNavigate(Screen.Voice.route)
                }

                QuickActionCard(
                    title = "Settings Control",
                    subtitle = "Bluetooth, WiFi",
                    icon = Icons.Default.Settings,
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.sendMessage("Open Bluetooth settings") { onNavigate(Screen.Chat.route) }
                }
            }
        }

        // 6. Suggested Prompts (Interactive Entry Points)
        item {
            Text(
                text = "SUGGESTED COMMANDS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(suggestedPrompts) { prompt ->
                    Box(
                        modifier = Modifier
                            .nexaCard(shape = RoundedCornerShape(16.dp), elevation = 2.dp)
                            .clickable {
                                viewModel.sendMessage(prompt) { onNavigate(Screen.Chat.route) }
                            }
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = prompt,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = null,
                                tint = NexaPrimaryBlue,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        // 7. Recent Conversations
        if (recentConversations.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RECENT CONVERSATIONS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "View All",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NexaPrimaryBlue,
                        modifier = Modifier.clickable { onNavigate(Screen.History.route) }
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    recentConversations.take(3).forEach { conv ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .nexaCard(elevation = 2.dp)
                                .clickable {
                                    viewModel.selectConversation(conv.id)
                                    onNavigate(Screen.Chat.route)
                                }
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = conv.title,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${conv.provider} • ${conv.model}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Open Chat",
                                tint = NexaElectricBlue,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .nexaCard(elevation = 3.dp)
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(NexaIceBlue),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = NexaPrimaryBlue,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = title,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = subtitle,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}


