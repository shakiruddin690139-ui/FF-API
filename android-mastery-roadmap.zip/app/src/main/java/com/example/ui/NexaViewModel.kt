package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.NexaApplication
import com.example.ai.model.AiMessage
import com.example.ai.model.AiProviderType
import com.example.ai.model.AiRequest
import com.example.ai.model.AiStreamEvent
import com.example.automation.commands.ActionResult
import com.example.automation.commands.DeviceAction
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.ConversationEntity
import com.example.data.local.entity.ProjectEntity
import com.example.media.video.TextAnimationType
import com.example.media.video.VideoAspectRatio
import com.example.media.video.VideoProjectState
import com.example.voice.ContinuousVoiceService
import com.example.voice.NexaVoiceManager
import com.example.voice.VoiceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import java.util.UUID

class NexaViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as NexaApplication
    private val db = app.database
    private val prefs = app.userPreferences
    private val providerManager = app.providerManager
    private val actionInterpreter = app.actionInterpreter
    private val actionExecutor = app.actionExecutor
    private val videoComposer = app.videoComposer

    // Voice Manager
    val voiceManager = NexaVoiceManager(application) { recognizedSpeech ->
        onVoiceSpeechTranscribed(recognizedSpeech)
    }

    // Active Provider & Model
    val selectedProviderFlow = prefs.selectedProviderFlow.stateIn(
        viewModelScope, SharingStarted.Eagerly, "GEMINI"
    )
    val grokModelFlow = prefs.grokModelFlow.stateIn(
        viewModelScope, SharingStarted.Eagerly, "grok-2-latest"
    )
    val openAiModelFlow = prefs.openAiModelFlow.stateIn(
        viewModelScope, SharingStarted.Eagerly, "gpt-4o-mini"
    )
    val geminiModelFlow = prefs.geminiModelFlow.stateIn(
        viewModelScope, SharingStarted.Eagerly, "gemini-2.5-flash"
    )
    val voiceLanguageFlow = prefs.voiceLanguageFlow.stateIn(
        viewModelScope, SharingStarted.Eagerly, "en-US"
    )
    val speechSpeedFlow = prefs.speechSpeedFlow.stateIn(
        viewModelScope, SharingStarted.Eagerly, 1.0f
    )
    val continuousListeningFlow = prefs.continuousListeningFlow.stateIn(
        viewModelScope, SharingStarted.Eagerly, false
    )
    val autoSpeakResponseFlow = prefs.autoSpeakResponseFlow.stateIn(
        viewModelScope, SharingStarted.Eagerly, true
    )
    val darkThemeFlow = prefs.darkThemeFlow.stateIn(
        viewModelScope, SharingStarted.Eagerly, false
    )
    val followSystemThemeFlow = prefs.followSystemThemeFlow.stateIn(
        viewModelScope, SharingStarted.Eagerly, true
    )

    // Current Conversation & Messages
    private val _currentConversationId = MutableStateFlow<String?>(null)
    val currentConversationId: StateFlow<String?> = _currentConversationId.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val messages: StateFlow<List<ChatMessageEntity>> = _messages.asStateFlow()

    val conversationsFlow = db.conversationDao().getAllConversations().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Streaming state
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingText = MutableStateFlow("")
    val streamingText: StateFlow<String> = _streamingText.asStateFlow()

    private var currentGenerationJob: Job? = null

    // Attachment state for chat composer
    private val _attachedImageUri = MutableStateFlow<Uri?>(null)
    val attachedImageUri: StateFlow<Uri?> = _attachedImageUri.asStateFlow()

    // Last Executed Action Result
    private val _lastActionResult = MutableStateFlow<ActionResult?>(null)
    val lastActionResult: StateFlow<ActionResult?> = _lastActionResult.asStateFlow()

    // Video Studio Project State
    private val _videoProject = MutableStateFlow(VideoProjectState())
    val videoProject: StateFlow<VideoProjectState> = _videoProject.asStateFlow()

    // Test connectivity status map
    private val _testResults = MutableStateFlow<Map<AiProviderType, String>>(emptyList<Pair<AiProviderType, String>>().toMap())
    val testResults: StateFlow<Map<AiProviderType, String>> = _testResults.asStateFlow()

    private val _isTestingApi = MutableStateFlow(false)
    val isTestingApi: StateFlow<Boolean> = _isTestingApi.asStateFlow()

    init {
        // Observe voice language preference and update voice manager
        viewModelScope.launch {
            voiceLanguageFlow.collect { langTag ->
                val locale = if (langTag == "hi-IN") Locale("hi", "IN") else Locale.US
                voiceManager.setLanguage(locale)
            }
        }
        viewModelScope.launch {
            speechSpeedFlow.collect { speed ->
                voiceManager.setSpeechRate(speed)
            }
        }
        viewModelScope.launch {
            continuousListeningFlow.collect { enabled ->
                if (enabled) {
                    ContinuousVoiceService.startService(getApplication())
                } else {
                    ContinuousVoiceService.stopService(getApplication())
                }
            }
        }
        // Start or restore default initial conversation
        viewModelScope.launch {
            conversationsFlow.collect { list ->
                if (_currentConversationId.value == null && list.isNotEmpty()) {
                    loadConversation(list.first().id)
                }
            }
        }
    }

    fun selectConversation(id: String) {
        loadConversation(id)
    }

    fun startNewConversation() {
        val newId = UUID.randomUUID().toString()
        val provider = selectedProviderFlow.value
        val model = getModelForProvider(AiProviderType.fromId(provider))
        val newConv = ConversationEntity(
            id = newId,
            title = "New Conversation",
            provider = provider,
            model = model,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        viewModelScope.launch {
            db.conversationDao().insertConversation(newConv)
            _currentConversationId.value = newId
            _messages.value = emptyList()
        }
    }

    private fun loadConversation(id: String) {
        _currentConversationId.value = id
        viewModelScope.launch {
            db.chatMessageDao().getMessagesForConversation(id).collect {
                _messages.value = it
            }
        }
    }

    fun setAttachedImage(uri: Uri?) {
        _attachedImageUri.value = uri
    }

    fun clearActionResult() {
        _lastActionResult.value = null
    }

    /**
     * Send message from user.
     * Evaluates whether the request is a device action or an AI chat query.
     */
    fun sendMessage(content: String, onNavigateToChat: (() -> Unit)? = null) {
        if (content.isBlank() && _attachedImageUri.value == null) return

        val trimmed = content.trim()
        val imageUri = _attachedImageUri.value
        _attachedImageUri.value = null

        // Check for natural language device command first!
        val detectedAction = actionInterpreter.interpret(trimmed)
        if (detectedAction != null) {
            val result = actionExecutor.execute(detectedAction)
            _lastActionResult.value = result

            // Also record in conversation as an action record
            recordActionInChat(trimmed, detectedAction, result)
            onNavigateToChat?.invoke()
            return
        }

        // Standard AI Chat flow
        ensureActiveConversation { convId ->
            viewModelScope.launch {
                val userMsg = ChatMessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = convId,
                    role = "user",
                    content = trimmed,
                    timestamp = System.currentTimeMillis(),
                    attachedMediaUri = imageUri?.toString()
                )
                db.chatMessageDao().insertMessage(userMsg)

                // Update conversation title if it's the first message
                val currentConv = db.conversationDao().getConversationById(convId)
                if (currentConv != null && (currentConv.title == "New Conversation" || currentConv.title.isBlank())) {
                    val newTitle = if (trimmed.length > 32) trimmed.take(30) + "…" else trimmed
                    db.conversationDao().updateConversation(currentConv.copy(title = newTitle, updatedAt = System.currentTimeMillis()))
                }

                // Call AI provider
                triggerAiGeneration(convId, userMsg, imageUri)
            }
        }
        onNavigateToChat?.invoke()
    }

    private fun recordActionInChat(prompt: String, action: DeviceAction, result: ActionResult) {
        ensureActiveConversation { convId ->
            viewModelScope.launch {
                val userMsg = ChatMessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = convId,
                    role = "user",
                    content = prompt,
                    timestamp = System.currentTimeMillis()
                )
                db.chatMessageDao().insertMessage(userMsg)

                val assistantMsg = ChatMessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = convId,
                    role = "action",
                    content = result.feedbackMessage,
                    timestamp = System.currentTimeMillis() + 50,
                    actionPayload = action.title
                )
                db.chatMessageDao().insertMessage(assistantMsg)
            }
        }
    }

    private fun triggerAiGeneration(convId: String, userMsg: ChatMessageEntity, imageUri: Uri?) {
        val providerType = AiProviderType.fromId(selectedProviderFlow.value)
        val model = getModelForProvider(providerType)
        val apiKey = providerManager.getApiKey(providerType)

        currentGenerationJob?.cancel()
        _isGenerating.value = true
        _streamingText.value = ""

        currentGenerationJob = viewModelScope.launch {
            var imageBase64: String? = null
            var mimeType: String? = null
            if (imageUri != null) {
                withContext(Dispatchers.IO) {
                    try {
                        val inputStream = getApplication<NexaApplication>().contentResolver.openInputStream(imageUri)
                        val bitmap = BitmapFactory.decodeStream(inputStream)
                        val baos = ByteArrayOutputStream()
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, baos)
                        imageBase64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                        mimeType = "image/jpeg"
                    } catch (_: Exception) {}
                }
            }

            // Build message context from current history
            val existing = _messages.value.takeLast(10).map {
                AiMessage(role = it.role, content = it.content)
            }
            val requestMessages = existing + listOf(
                AiMessage(role = "user", content = userMsg.content, imageBase64 = imageBase64, mimeType = mimeType)
            )

            val request = AiRequest(
                provider = providerType,
                model = model,
                messages = requestMessages,
                apiKey = apiKey
            )

            val provider = providerManager.getProvider(providerType)
            val accumulated = StringBuilder()

            try {
                provider.streamResponse(request).collect { event ->
                    when (event) {
                        is AiStreamEvent.Chunk -> {
                            accumulated.append(event.text)
                            _streamingText.value = accumulated.toString()
                        }
                        is AiStreamEvent.Completed -> {
                            saveAssistantResponse(convId, event.fullText, providerType, model, isError = false)
                        }
                        is AiStreamEvent.Error -> {
                            saveAssistantResponse(convId, "Error: ${event.error}", providerType, model, isError = true)
                        }
                    }
                }
            } catch (e: Exception) {
                saveAssistantResponse(convId, "Request failed: ${e.localizedMessage ?: "Unknown error"}", providerType, model, isError = true)
            } finally {
                _isGenerating.value = false
                _streamingText.value = ""
            }
        }
    }

    private suspend fun saveAssistantResponse(
        convId: String,
        text: String,
        provider: AiProviderType,
        model: String,
        isError: Boolean
    ) {
        val assistantMsg = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = convId,
            role = "assistant",
            content = text,
            timestamp = System.currentTimeMillis(),
            providerUsed = provider.displayName,
            modelUsed = model,
            isError = isError
        )
        db.chatMessageDao().insertMessage(assistantMsg)

        // If auto-speak enabled and not error, speak via TTS
        if (!isError && autoSpeakResponseFlow.value) {
            voiceManager.speak(text)
        }
    }

    fun stopGeneration() {
        currentGenerationJob?.cancel()
        _isGenerating.value = false
        _streamingText.value = ""
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            db.conversationDao().deleteConversationById(id)
            if (_currentConversationId.value == id) {
                _currentConversationId.value = null
                _messages.value = emptyList()
            }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            db.conversationDao().clearAllConversations()
            db.chatMessageDao().clearAllMessages()
            _currentConversationId.value = null
            _messages.value = emptyList()
        }
    }

    fun renameConversation(id: String, newTitle: String) {
        viewModelScope.launch {
            val conv = db.conversationDao().getConversationById(id)
            if (conv != null) {
                db.conversationDao().updateConversation(conv.copy(title = newTitle))
            }
        }
    }

    // Voice callback handler
    private fun onVoiceSpeechTranscribed(text: String) {
        if (text.isBlank()) return
        sendMessage(text)
    }

    // Settings actions
    fun setSelectedProvider(provider: AiProviderType) {
        viewModelScope.launch {
            prefs.setSelectedProvider(provider.id)
        }
    }

    fun setModelForProvider(provider: AiProviderType, model: String) {
        viewModelScope.launch {
            when (provider) {
                AiProviderType.GROK -> prefs.setGrokModel(model)
                AiProviderType.OPENAI -> prefs.setOpenAiModel(model)
                AiProviderType.GEMINI -> prefs.setGeminiModel(model)
            }
        }
    }

    fun getModelForProvider(provider: AiProviderType): String {
        return when (provider) {
            AiProviderType.GROK -> grokModelFlow.value
            AiProviderType.OPENAI -> openAiModelFlow.value
            AiProviderType.GEMINI -> geminiModelFlow.value
        }
    }

    fun saveApiKey(provider: AiProviderType, key: String) {
        providerManager.saveApiKey(provider, key)
    }

    fun getMaskedApiKey(provider: AiProviderType): String {
        return providerManager.getMaskedKey(provider)
    }

    fun hasApiKey(provider: AiProviderType): Boolean {
        return providerManager.hasApiKey(provider)
    }

    fun testProviderConnectivity(provider: AiProviderType) {
        viewModelScope.launch {
            _isTestingApi.value = true
            val model = getModelForProvider(provider)
            val result = providerManager.testConnectivity(provider, model)
            val currentMap = _testResults.value.toMutableMap()
            currentMap[provider] = if (result.isSuccess) {
                "Success: ${result.getOrNull()}"
            } else {
                "Error: ${result.exceptionOrNull()?.localizedMessage ?: "Failed"}"
            }
            _testResults.value = currentMap
            _isTestingApi.value = false
        }
    }

    fun setVoiceLanguage(lang: String) {
        viewModelScope.launch { prefs.setVoiceLanguage(lang) }
    }

    fun setSpeechSpeed(speed: Float) {
        viewModelScope.launch { prefs.setSpeechSpeed(speed) }
    }

    fun setContinuousListening(enabled: Boolean) {
        viewModelScope.launch { prefs.setContinuousListening(enabled) }
    }

    fun setAutoSpeakResponse(enabled: Boolean) {
        viewModelScope.launch { prefs.setAutoSpeakResponse(enabled) }
    }

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setDarkTheme(enabled)
            prefs.setFollowSystemTheme(false)
        }
    }

    fun setFollowSystemTheme(enabled: Boolean) {
        viewModelScope.launch { prefs.setFollowSystemTheme(enabled) }
    }

    // Video Studio actions
    fun updateVideoScript(script: String) {
        val captions = videoComposer.parseScriptToCaptions(script, _videoProject.value.durationSeconds)
        _videoProject.value = _videoProject.value.copy(
            scriptText = script,
            timedCaptions = captions
        )
    }

    fun setVideoAspectRatio(ratio: VideoAspectRatio) {
        _videoProject.value = _videoProject.value.copy(aspectRatio = ratio)
    }

    fun setTextAnimationType(anim: TextAnimationType) {
        _videoProject.value = _videoProject.value.copy(animationType = anim)
    }

    fun setVideoDuration(seconds: Int) {
        val currentScript = _videoProject.value.scriptText
        val captions = videoComposer.parseScriptToCaptions(currentScript, seconds)
        _videoProject.value = _videoProject.value.copy(
            durationSeconds = seconds,
            timedCaptions = captions
        )
    }

    fun generateAiScript(topic: String) {
        val prompt = "Write a high-retention viral 15-second vertical video script with punchy lines on: $topic. Keep it concise, engaging, without stage directions."
        val providerType = AiProviderType.fromId(selectedProviderFlow.value)
        val model = getModelForProvider(providerType)
        val apiKey = providerManager.getApiKey(providerType)

        viewModelScope.launch {
            val req = AiRequest(
                provider = providerType,
                model = model,
                messages = listOf(AiMessage("user", prompt)),
                maxTokens = 250,
                apiKey = apiKey
            )
            val res = providerManager.getProvider(providerType).generateResponse(req)
            if (res.isSuccess && res.text.isNotBlank()) {
                updateVideoScript(res.text.trim())
            }
        }
    }

    fun renderAndExportVideo() {
        val proj = _videoProject.value
        _videoProject.value = proj.copy(isRendering = true, renderProgress = 0f)

        viewModelScope.launch {
            videoComposer.renderProject(proj).collect { progress ->
                _videoProject.value = _videoProject.value.copy(renderProgress = progress)
                if (progress >= 1.0f) {
                    val exportDir = File(getApplication<NexaApplication>().filesDir, "nexa_exports")
                    val latestFile = exportDir.listFiles()?.maxByOrNull { it.lastModified() }
                    _videoProject.value = _videoProject.value.copy(
                        isRendering = false,
                        renderedFilePath = latestFile?.absolutePath
                    )
                    // Save to Room DB
                    db.projectDao().insertProject(
                        ProjectEntity(
                            id = proj.id,
                            title = proj.title,
                            type = "ANIMATED_TEXT",
                            aspectRatio = proj.aspectRatio.name,
                            scriptText = proj.scriptText,
                            textAnimation = proj.animationType.name,
                            mediaUrisJson = "[]",
                            durationSeconds = proj.durationSeconds,
                            createdAt = System.currentTimeMillis()
                        )
                    )
                }
            }
        }
    }

    fun shareCurrentRenderedVideo() {
        val path = _videoProject.value.renderedFilePath ?: return
        val file = File(path)
        if (file.exists()) {
            videoComposer.shareExportedVideo(file)
        }
    }

    private fun ensureActiveConversation(onReady: (String) -> Unit) {
        val currentId = _currentConversationId.value
        if (currentId != null) {
            onReady(currentId)
        } else {
            val newId = UUID.randomUUID().toString()
            val provider = selectedProviderFlow.value
            val model = getModelForProvider(AiProviderType.fromId(provider))
            val newConv = ConversationEntity(
                id = newId,
                title = "New Conversation",
                provider = provider,
                model = model,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            viewModelScope.launch {
                db.conversationDao().insertConversation(newConv)
                _currentConversationId.value = newId
                onReady(newId)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}
