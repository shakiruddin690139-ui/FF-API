package com.example.ui.chat

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.ai.model.AiProviderType
import com.example.data.local.entity.ChatMessageEntity
import com.example.ui.NexaViewModel
import com.example.ui.theme.NexaElectricBlue
import com.example.ui.theme.NexaError
import com.example.ui.theme.NexaIceBlue
import com.example.ui.theme.NexaPrimaryBlue
import com.example.ui.theme.NexaPrimaryGradient
import com.example.ui.theme.NexaRoyalBlue
import com.example.ui.theme.NexaSecondaryBackground
import com.example.ui.theme.NexaSecondaryText
import com.example.ui.theme.NexaSuccess
import com.example.ui.theme.nexaCard
import com.example.ui.theme.nexaGlowButton

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: NexaViewModel,
    onNavigateToVoice: () -> Unit
) {
    val messages by viewModel.messages.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val streamingText by viewModel.streamingText.collectAsState()
    val attachedImageUri by viewModel.attachedImageUri.collectAsState()
    val selectedProviderStr by viewModel.selectedProviderFlow.collectAsState()
    val activeProvider = AiProviderType.fromId(selectedProviderStr)
    val activeModel = viewModel.getModelForProvider(activeProvider)

    val listState = rememberLazyListState()
    var inputText by remember { mutableStateOf("") }
    val clipboardManager = LocalClipboardManager.current

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        viewModel.setAttachedImage(uri)
    }

    LaunchedEffect(messages.size, streamingText) {
        if (messages.isNotEmpty() || streamingText.isNotEmpty()) {
            listState.animateScrollToItem(index = (messages.size + if (isGenerating) 1 else 0))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "NEXA AI Chat",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "${activeProvider.displayName} • $activeModel",
                    fontSize = 11.sp,
                    color = NexaPrimaryBlue,
                    fontWeight = FontWeight.Medium
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier
                        .nexaCard(shape = RoundedCornerShape(12.dp), elevation = 2.dp)
                        .clickable { viewModel.startNewConversation() }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("new_chat_button")
                ) {
                    Text(
                        text = "+ New Chat",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NexaPrimaryBlue
                    )
                }
            }
        }

        // Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (messages.isEmpty() && !isGenerating) {
                item {
                    EmptyChatGreeting(activeProvider = activeProvider) { prompt ->
                        viewModel.sendMessage(prompt)
                    }
                }
            }

            items(messages, key = { it.id }) { msg ->
                ChatMessageItem(
                    message = msg,
                    onCopy = { clipboardManager.setText(AnnotatedString(msg.content)) },
                    onSpeak = { viewModel.voiceManager.speak(msg.content) }
                )
            }

            // Live Streaming bubble if currently generating
            if (isGenerating && streamingText.isNotEmpty()) {
                item {
                    StreamingMessageItem(
                        streamingText = streamingText,
                        provider = activeProvider.displayName
                    )
                }
            } else if (isGenerating) {
                item {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = NexaPrimaryBlue
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "NEXA is thinking...",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Attached image preview if any
        AnimatedVisibility(visible = attachedImageUri != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(60.dp)) {
                    Image(
                        painter = rememberAsyncImagePainter(attachedImageUri),
                        contentDescription = "Attached Image",
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.6f))
                            .clickable { viewModel.setAttachedImage(null) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Remove",
                            tint = Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Image attached for AI analysis",
                    fontSize = 12.sp,
                    color = NexaPrimaryBlue
                )
            }
        }

        // Bottom Composer Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .nexaCard(elevation = 6.dp, shape = RoundedCornerShape(24.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Attach Image",
                    tint = NexaPrimaryBlue
                )
            }

            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = {
                    Text(
                        "Type a message or device command...",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent
                ),
                maxLines = 4
            )

            if (isGenerating) {
                IconButton(
                    onClick = { viewModel.stopGeneration() },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(NexaError.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop",
                        tint = NexaError
                    )
                }
            } else if (inputText.isNotBlank() || attachedImageUri != null) {
                IconButton(
                    onClick = {
                        val text = inputText
                        inputText = ""
                        viewModel.sendMessage(text)
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .nexaGlowButton(shape = CircleShape, elevation = 2.dp)
                        .testTag("chat_send_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            } else {
                IconButton(
                    onClick = onNavigateToVoice,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(NexaIceBlue)
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Voice",
                        tint = NexaPrimaryBlue,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ChatMessageItem(
    message: ChatMessageEntity,
    onCopy: () -> Unit,
    onSpeak: () -> Unit
) {
    val isUser = message.role == "user"
    val isAction = message.role == "action"

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .clip(
                    RoundedCornerShape(
                        topStart = 20.dp,
                        topEnd = 20.dp,
                        bottomStart = if (isUser) 20.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 20.dp
                    )
                )
                .then(
                    when {
                        isUser -> Modifier.background(NexaPrimaryGradient)
                        isAction -> Modifier.background(NexaIceBlue)
                        message.isError -> Modifier.background(NexaError.copy(alpha = 0.1f))
                        else -> Modifier.background(MaterialTheme.colorScheme.surface)
                    }
                )
                .border(
                    width = 1.dp,
                    color = if (isUser) Color.Transparent else NexaIceBlue,
                    shape = RoundedCornerShape(20.dp)
                )
                .padding(14.dp)
        ) {
            // Header on assistant/action messages
            if (!isUser) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isAction) "DEVICE ACTION" else (message.providerUsed.ifBlank { "NEXA AI" }),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isAction) NexaRoyalBlue else NexaElectricBlue
                    )

                    Row {
                        IconButton(
                            onClick = onSpeak,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Read Aloud",
                                tint = NexaSecondaryText,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        IconButton(
                            onClick = onCopy,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy Message",
                                tint = NexaSecondaryText,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
            }

            // Attached image if user uploaded
            if (message.attachedMediaUri != null) {
                Image(
                    painter = rememberAsyncImagePainter(message.attachedMediaUri),
                    contentDescription = "Attached Media",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Render Markdown or code blocks if present
            if (message.content.contains("```")) {
                CodeFormattedContent(text = message.content)
            } else {
                Text(
                    text = message.content,
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
private fun StreamingMessageItem(
    streamingText: String,
    provider: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.surface)
                .border(width = 1.dp, color = NexaIceBlue, shape = RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Text(
                text = "$provider • Generating...",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = NexaElectricBlue
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = streamingText,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun CodeFormattedContent(text: String) {
    val clipboard = LocalClipboardManager.current
    val parts = text.split("```")

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        parts.forEachIndexed { index, part ->
            if (index % 2 == 1) {
                // Code Block
                val lines = part.trim().lines()
                val lang = lines.firstOrNull()?.trim() ?: "code"
                val codeBody = if (lines.size > 1) lines.drop(1).joinToString("\n") else part

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0F172A))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = lang.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Code",
                            tint = Color.White,
                            modifier = Modifier
                                .size(16.dp)
                                .clickable { clipboard.setText(AnnotatedString(codeBody)) }
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = codeBody,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFFF1F5F9),
                        lineHeight = 18.sp
                    )
                }
            } else if (part.isNotBlank()) {
                Text(
                    text = part.trim(),
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
private fun EmptyChatGreeting(
    activeProvider: AiProviderType,
    onPromptClick: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(NexaIceBlue),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = null,
                tint = NexaPrimaryBlue,
                modifier = Modifier.size(32.dp)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Welcome to NEXA AI",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = "Powered by ${activeProvider.displayName}. Ask questions or issue voice device actions.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                "Open YouTube and search Free Fire",
                "Explain quantum computing simply",
                "Create a 15s viral video script on AI",
                "Turn Bluetooth on in settings"
            ).forEach { prompt ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .nexaCard(elevation = 2.dp)
                        .clickable { onPromptClick(prompt) }
                        .padding(12.dp)
                ) {
                    Text(
                        text = prompt,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = NexaPrimaryBlue
                    )
                }
            }
        }
    }
}
