package com.example.ui.voice

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.NexaViewModel
import com.example.ui.theme.NexaElectricBlue
import com.example.ui.theme.NexaError
import com.example.ui.theme.NexaIceBlue
import com.example.ui.theme.NexaPrimaryBlue
import com.example.ui.theme.NexaPrimaryGradient
import com.example.ui.theme.NexaRoyalBlue
import com.example.ui.theme.NexaSecondaryBackground
import com.example.ui.theme.NexaSuccess
import com.example.ui.theme.nexaCard
import com.example.ui.theme.nexaGlowButton
import com.example.voice.VoiceState

@Composable
fun VoiceAssistantScreen(
    viewModel: NexaViewModel,
    onNavigateToChat: () -> Unit
) {
    val context = LocalContext.current
    val voiceState by viewModel.voiceManager.voiceState.collectAsState()
    val voiceLanguage by viewModel.voiceLanguageFlow.collectAsState()
    val autoSpeak by viewModel.autoSpeakResponseFlow.collectAsState()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
        if (isGranted) {
            viewModel.voiceManager.startListening()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // 1. Top Section: Header & Language Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "NEXA Voice Assistant",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = if (autoSpeak) "Voice Conversation Active" else "Speech-to-Text Active",
                    fontSize = 12.sp,
                    color = NexaPrimaryBlue
                )
            }

            // Language Pill Toggle (English vs Hindi)
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(NexaSecondaryBackground)
                    .padding(4.dp)
            ) {
                val isEnglish = voiceLanguage == "en-US"
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .then(
                            if (isEnglish) Modifier.background(NexaPrimaryGradient)
                            else Modifier.background(Color.Transparent)
                        )
                        .clickable { viewModel.setVoiceLanguage("en-US") }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "EN",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isEnglish) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .then(
                            if (!isEnglish) Modifier.background(NexaPrimaryGradient)
                            else Modifier.background(Color.Transparent)
                        )
                        .clickable { viewModel.setVoiceLanguage("hi-IN") }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "हिंदी",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (!isEnglish) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // 2. Middle Section: Pulsing 3D AI Energy Flame / Orb Canvas
        Box(
            modifier = Modifier
                .size(280.dp),
            contentAlignment = Alignment.Center
        ) {
            VoiceAssistantEnergyVisualizer(voiceState = voiceState)

            // Center status glyph
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .nexaCard(shape = CircleShape, elevation = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (voiceState) {
                        is VoiceState.Speaking -> Icons.Default.Stop
                        is VoiceState.Error -> Icons.Default.Refresh
                        else -> Icons.Default.Mic
                    },
                    contentDescription = "Voice State",
                    tint = when (voiceState) {
                        is VoiceState.Listening -> NexaPrimaryBlue
                        is VoiceState.Processing -> NexaElectricBlue
                        is VoiceState.Speaking -> NexaRoyalBlue
                        is VoiceState.Error -> NexaError
                        else -> NexaPrimaryBlue
                    },
                    modifier = Modifier.size(40.dp)
                )
            }
        }

        // 3. Status Text & Live Transcription Box
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = when (voiceState) {
                    is VoiceState.Listening -> "Listening... Speak your command"
                    is VoiceState.Processing -> "Processing with AI..."
                    is VoiceState.Speaking -> "NEXA is speaking..."
                    is VoiceState.Error -> (voiceState as VoiceState.Error).message
                    else -> "Tap the microphone below to talk"
                },
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = when (voiceState) {
                    is VoiceState.Error -> NexaError
                    is VoiceState.Listening -> NexaPrimaryBlue
                    else -> MaterialTheme.colorScheme.onBackground
                },
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Transcription card
            val transcribedText = when (voiceState) {
                is VoiceState.Listening -> (voiceState as VoiceState.Listening).partialText
                is VoiceState.Processing -> (voiceState as VoiceState.Processing).promptText
                is VoiceState.Speaking -> (voiceState as VoiceState.Speaking).spokenText
                else -> ""
            }

            if (transcribedText.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .nexaCard(elevation = 2.dp)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "\"$transcribedText\"",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            } else {
                Text(
                    text = "Try: \"Open YouTube\", \"Create animated text video\", or \"Tell me a story\"",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }

        // 4. Bottom Controls: Big Action Button & Session Controls
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (!hasMicPermission) {
                Button(
                    onClick = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .nexaGlowButton(shape = RoundedCornerShape(16.dp)),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                ) {
                    Text(
                        text = "Grant Microphone Permission",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Cancel / Stop session
                    IconButton(
                        onClick = { viewModel.voiceManager.cancelVoiceSession() },
                        modifier = Modifier
                            .size(52.dp)
                            .nexaCard(shape = CircleShape, elevation = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cancel",
                            tint = NexaError
                        )
                    }

                    // Main Big Mic Button (72dp)
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .nexaGlowButton(shape = CircleShape, elevation = 6.dp)
                            .clickable {
                                when (voiceState) {
                                    is VoiceState.Speaking -> viewModel.voiceManager.stopSpeaking()
                                    is VoiceState.Listening -> viewModel.voiceManager.stopListening()
                                    else -> viewModel.voiceManager.startListening()
                                }
                            }
                            .testTag("voice_mic_main_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (voiceState) {
                                is VoiceState.Speaking -> Icons.Default.Stop
                                else -> Icons.Default.Mic
                            },
                            contentDescription = "Toggle Mic",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    // Switch to Chat text mode
                    IconButton(
                        onClick = onNavigateToChat,
                        modifier = Modifier
                            .size(52.dp)
                            .nexaCard(shape = CircleShape, elevation = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Go to Chat",
                            tint = NexaPrimaryBlue
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VoiceAssistantEnergyVisualizer(voiceState: VoiceState) {
    val infiniteTransition = rememberInfiniteTransition(label = "energy_orb")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val waveAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_alpha"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val baseRadius = size.width * 0.32f

        val outerColor = when (voiceState) {
            is VoiceState.Listening -> NexaElectricBlue
            is VoiceState.Processing -> NexaRoyalBlue
            is VoiceState.Speaking -> NexaPrimaryBlue
            is VoiceState.Error -> NexaError
            else -> NexaIceBlue
        }

        // Outer expanding radiant wave
        if (voiceState is VoiceState.Listening || voiceState is VoiceState.Speaking) {
            drawCircle(
                color = outerColor.copy(alpha = waveAlpha),
                radius = baseRadius * 1.4f * pulseScale,
                center = center
            )
            drawCircle(
                color = outerColor.copy(alpha = waveAlpha * 1.3f),
                radius = baseRadius * 1.2f * pulseScale,
                center = center
            )
        }

        // Soft 3D glowing gradient orb
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    outerColor.copy(alpha = 0.7f),
                    outerColor.copy(alpha = 0.25f),
                    Color.Transparent
                ),
                center = center,
                radius = baseRadius * pulseScale
            ),
            radius = baseRadius * pulseScale,
            center = center
        )
    }
}
