package com.example.ai.provider

import com.example.BuildConfig
import com.example.ai.model.AiMessage
import com.example.ai.model.AiProviderType
import com.example.ai.model.AiRequest
import com.example.ai.model.AiResponse
import com.example.ai.model.AiStreamEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

class GeminiProvider(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
) : AiProvider {

    override val providerType: AiProviderType = AiProviderType.GEMINI

    private fun resolveApiKey(userKey: String): String {
        if (userKey.isNotBlank()) return userKey.trim()
        return try {
            val field = BuildConfig::class.java.getField("GEMINI_API_KEY")
            val buildKey = field.get(null) as? String
            if (!buildKey.isNullOrBlank() && !buildKey.contains("MY_GEMINI_API_KEY")) {
                buildKey.trim()
            } else ""
        } catch (_: Exception) {
            ""
        }
    }

    override suspend fun generateResponse(request: AiRequest): AiResponse = withContext(Dispatchers.IO) {
        val apiKey = resolveApiKey(request.apiKey)
        if (apiKey.isBlank()) {
            return@withContext AiResponse(
                text = "",
                provider = providerType,
                model = request.model,
                isSuccess = false,
                errorMessage = "Google Gemini API key not configured. Please add your key in Settings -> API Keys."
            )
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/${request.model}:generateContent?key=$apiKey"
        try {
            val payload = buildJsonPayload(request)
            val httpRequest = Request.Builder()
                .url(url)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(httpRequest).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext AiResponse(
                        text = "",
                        provider = providerType,
                        model = request.model,
                        isSuccess = false,
                        errorMessage = parseErrorBody(response.code, body)
                    )
                }

                val json = JSONObject(body)
                val candidates = json.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val contentObj = candidates.getJSONObject(0).optJSONObject("content")
                    val parts = contentObj?.optJSONArray("parts")
                    val textBuilder = StringBuilder()
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val part = parts.getJSONObject(i)
                            textBuilder.append(part.optString("text", ""))
                        }
                    }
                    val text = textBuilder.toString()
                    AiResponse(
                        text = text,
                        provider = providerType,
                        model = request.model,
                        isSuccess = true
                    )
                } else {
                    AiResponse(
                        text = "",
                        provider = providerType,
                        model = request.model,
                        isSuccess = false,
                        errorMessage = "Received empty candidates from Gemini."
                    )
                }
            }
        } catch (e: Exception) {
            AiResponse(
                text = "",
                provider = providerType,
                model = request.model,
                isSuccess = false,
                errorMessage = "Gemini connection error: ${e.localizedMessage ?: "Unknown error"}"
            )
        }
    }

    override suspend fun streamResponse(request: AiRequest): Flow<AiStreamEvent> = flow {
        val apiKey = resolveApiKey(request.apiKey)
        if (apiKey.isBlank()) {
            emit(AiStreamEvent.Error("Gemini API key not configured. Add it in Settings."))
            return@flow
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/${request.model}:streamGenerateContent?alt=sse&key=$apiKey"
        val payload = buildJsonPayload(request)
        val httpRequest = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val fullTextBuilder = StringBuilder()

        try {
            val response = client.newCall(httpRequest).execute()
            if (!response.isSuccessful) {
                val errorBody = response.body?.string().orEmpty()
                emit(AiStreamEvent.Error(parseErrorBody(response.code, errorBody)))
                response.close()
                return@flow
            }

            val body = response.body ?: run {
                emit(AiStreamEvent.Error("Null response stream"))
                return@flow
            }

            BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8)).use { reader ->
                var line: String? = reader.readLine()
                while (line != null) {
                    val trimmed = line.trim()
                    if (trimmed.startsWith("data:")) {
                        val dataContent = trimmed.removePrefix("data:").trim()
                        if (dataContent.isNotBlank()) {
                            try {
                                val chunkJson = JSONObject(dataContent)
                                val candidates = chunkJson.optJSONArray("candidates")
                                if (candidates != null && candidates.length() > 0) {
                                    val contentObj = candidates.getJSONObject(0).optJSONObject("content")
                                    val parts = contentObj?.optJSONArray("parts")
                                    if (parts != null) {
                                        for (i in 0 until parts.length()) {
                                            val token = parts.getJSONObject(i).optString("text", "")
                                            if (token.isNotEmpty()) {
                                                fullTextBuilder.append(token)
                                                emit(AiStreamEvent.Chunk(token))
                                            }
                                        }
                                    }
                                }
                            } catch (_: Exception) {
                                // Skip unparseable chunks
                            }
                        }
                    }
                    line = reader.readLine()
                }
            }

            emit(AiStreamEvent.Completed(fullTextBuilder.toString()))
        } catch (e: Exception) {
            emit(AiStreamEvent.Error("Streaming error: ${e.localizedMessage ?: "Connection interrupted"}"))
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun testConnectivity(apiKey: String, model: String): Result<String> = withContext(Dispatchers.IO) {
        val keyToTest = resolveApiKey(apiKey)
        if (keyToTest.isBlank()) {
            return@withContext Result.failure(Exception("Gemini API key is blank"))
        }

        try {
            val testRequest = AiRequest(
                provider = providerType,
                model = model,
                messages = listOf(AiMessage("user", "Hello! Return: Connected to Google Gemini successfully.")),
                maxTokens = 30,
                apiKey = keyToTest
            )
            val res = generateResponse(testRequest)
            if (res.isSuccess) {
                Result.success(res.text.ifBlank { "Google Gemini connection confirmed!" })
            } else {
                Result.failure(Exception(res.errorMessage ?: "Verification failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun buildJsonPayload(request: AiRequest): JSONObject {
        val root = JSONObject()
        val contentsArray = JSONArray()

        for (msg in request.messages) {
            val contentObj = JSONObject()
            // Map "assistant" to "model", "user" to "user"
            val role = if (msg.role == "assistant") "model" else "user"
            contentObj.put("role", role)

            val partsArray = JSONArray()
            val textPart = JSONObject()
            textPart.put("text", msg.content)
            partsArray.put(textPart)

            if (!msg.imageBase64.isNullOrBlank()) {
                val imagePart = JSONObject()
                val inlineData = JSONObject()
                inlineData.put("mime_type", msg.mimeType ?: "image/jpeg")
                inlineData.put("data", msg.imageBase64)
                imagePart.put("inline_data", inlineData)
                partsArray.put(imagePart)
            }

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
        }

        root.put("contents", contentsArray)

        val genConfig = JSONObject()
        genConfig.put("temperature", request.temperature)
        genConfig.put("maxOutputTokens", request.maxTokens)
        root.put("generationConfig", genConfig)

        return root
    }

    private fun parseErrorBody(code: Int, body: String): String {
        return try {
            val json = JSONObject(body)
            val error = json.optJSONObject("error")
            val message = error?.optString("message", "") ?: body
            when (code) {
                400 -> "Invalid request (400): $message"
                403 -> "API Key permission error (403): Invalid or restricted key."
                429 -> "Gemini rate limit exceeded (429). Please wait a moment."
                else -> "Gemini error $code: $message"
            }
        } catch (_: Exception) {
            "HTTP $code: $body"
        }
    }
}
