package com.example.ai.provider

import com.example.ai.model.AiProviderType

class GrokProvider : OpenAiCompatibleProvider() {
    override val providerType: AiProviderType = AiProviderType.GROK
    override val endpointUrl: String = "https://api.x.ai/v1/chat/completions"
}
