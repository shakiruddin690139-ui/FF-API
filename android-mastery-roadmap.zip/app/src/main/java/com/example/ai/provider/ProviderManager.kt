package com.example.ai.provider

import com.example.ai.model.AiProviderType
import com.example.core.security.KeyStoreHelper

class ProviderManager(private val keyStoreHelper: KeyStoreHelper) {

    private val grokProvider = GrokProvider()
    private val openAiProvider = OpenAiProvider()
    private val geminiProvider = GeminiProvider()

    fun getProvider(type: AiProviderType): AiProvider {
        return when (type) {
            AiProviderType.GROK -> grokProvider
            AiProviderType.OPENAI -> openAiProvider
            AiProviderType.GEMINI -> geminiProvider
        }
    }

    fun getApiKey(type: AiProviderType): String {
        val keyName = "api_key_${type.id.lowercase()}"
        return keyStoreHelper.getDecryptedKey(keyName)
    }

    fun saveApiKey(type: AiProviderType, key: String) {
        val keyName = "api_key_${type.id.lowercase()}"
        keyStoreHelper.saveEncryptedKey(keyName, key.trim())
    }

    fun getMaskedKey(type: AiProviderType): String {
        val keyName = "api_key_${type.id.lowercase()}"
        return keyStoreHelper.getMaskedKey(keyName)
    }

    fun hasApiKey(type: AiProviderType): Boolean {
        if (type == AiProviderType.GEMINI) {
            // Gemini can also use BuildConfig key if available
            val explicitKey = getApiKey(type)
            if (explicitKey.isNotBlank()) return true
            return try {
                val field = com.example.BuildConfig::class.java.getField("GEMINI_API_KEY")
                val buildKey = field.get(null) as? String
                buildKey != null && buildKey.isNotBlank() && !buildKey.contains("MY_GEMINI_API_KEY")
            } catch (_: Exception) {
                false
            }
        }
        val keyName = "api_key_${type.id.lowercase()}"
        return keyStoreHelper.hasKey(keyName)
    }

    suspend fun testConnectivity(type: AiProviderType, model: String): Result<String> {
        val provider = getProvider(type)
        val key = getApiKey(type)
        return provider.testConnectivity(key, model)
    }
}
