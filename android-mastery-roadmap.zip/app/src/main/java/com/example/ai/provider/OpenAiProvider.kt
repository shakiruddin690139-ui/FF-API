package com.example.ai.provider

import com.example.ai.model.AiProviderType

class OpenAiProvider : OpenAiCompatibleProvider() {
    override val providerType: AiProviderType = AiProviderType.OPENAI
    override val endpointUrl: String = "https://api.openai.com/v1/chat/completions"
}
