package com.example.ai.provider

import com.example.ai.model.AiMessage
import com.example.ai.model.AiProviderType
import com.example.ai.model.AiRequest
import com.example.ai.model.AiResponse
import com.example.ai.model.AiStreamEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

abstract class OpenAiCompatibleProvider(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
) : AiProvider {

    abstract val endpointUrl: String

    override suspend fun generateResponse(request: AiRequest): AiResponse = withContext(Dispatchers.IO) {
        if (request.apiKey.isBlank()) {
            return@withContext AiResponse(
                text = "",
                provider = providerType,
                model = request.model,
                isSuccess = false,
                errorMessage = "API Key not configured. Please enter your ${providerType.displayName} key in Settings."
            )
        }

        try {
            val payload = buildJsonPayload(request, stream = false)
            val httpRequest = Request.Builder()
                .url(endpointUrl)
                .addHeader("Authorization", "Bearer ${request.apiKey.trim()}")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(httpRequest).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errMsg = parseErrorBody(response.code, body)
                    return@withContext AiResponse(
                        text = "",
                        provider = providerType,
                        model = request.model,
                        isSuccess = false,
                        errorMessage = errMsg
                    )
                }

                val json = JSONObject(body)
                val choices = json.getJSONArray("choices")
                if (choices.length() > 0) {
                    val message = choices.getJSONObject(0).getJSONObject("message")
                    val content = message.optString("content", "")
                    return@withContext AiResponse(
                        text = content,
                        provider = providerType,
                        model = request.model,
                        isSuccess = true
                    )
                } else {
                    return@withContext AiResponse(
                        text = "",
                        provider = providerType,
                        model = request.model,
                        isSuccess = false,
                        errorMessage = "Received empty response from ${providerType.displayName}."
                    )
                }
            }
        } catch (e: Exception) {
            AiResponse(
                text = "",
                provider = providerType,
                model = request.model,
                isSuccess = false,
                errorMessage = "Network error: ${e.localizedMessage ?: "Failed to reach provider"}"
            )
        }
    }

    override suspend fun streamResponse(request: AiRequest): Flow<AiStreamEvent> = flow {
        if (request.apiKey.isBlank()) {
            emit(AiStreamEvent.Error("API Key not configured. Please configure your key in Settings."))
            return@flow
        }

        val payload = buildJsonPayload(request, stream = true)
        val httpRequest = Request.Builder()
            .url(endpointUrl)
            .addHeader("Authorization", "Bearer ${request.apiKey.trim()}")
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val fullTextBuilder = StringBuilder()

        try {
            val response = client.newCall(httpRequest).execute()
            if (!response.isSuccessful) {
                val errorBody = response.body?.string().orEmpty()
                emit(AiStreamEvent.Error(parseErrorBody(response.code, errorBody)))
                response.close()
                return@flow
            }

            val body = response.body ?: run {
                emit(AiStreamEvent.Error("Null response stream"))
                return@flow
            }

            BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8)).use { reader ->
                var line: String? = reader.readLine()
                while (line != null) {
                    val trimmed = line.trim()
                    if (trimmed.startsWith("data:")) {
                        val dataContent = trimmed.removePrefix("data:").trim()
                        if (dataContent == "[DONE]") {
                            break
                        }
                        if (dataContent.isNotBlank()) {
                            try {
                                val chunkJson = JSONObject(dataContent)
                                val choices = chunkJson.optJSONArray("choices")
                                if (choices != null && choices.length() > 0) {
                                    val delta = choices.getJSONObject(0).optJSONObject("delta")
                                    val token = delta?.optString("content", "").orEmpty()
                                    if (token.isNotEmpty()) {
                                        fullTextBuilder.append(token)
                                        emit(AiStreamEvent.Chunk(token))
                                    }
                                }
                            } catch (_: Exception) {
                                // Skip malformed stream chunk
                            }
                        }
                    }
                    line = reader.readLine()
                }
            }

            emit(AiStreamEvent.Completed(fullTextBuilder.toString()))
        } catch (e: Exception) {
            emit(AiStreamEvent.Error("Streaming error: ${e.localizedMessage ?: "Connection interrupted"}"))
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun testConnectivity(apiKey: String, model: String): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(Exception("API Key cannot be blank"))
        }

        try {
            val testRequest = AiRequest(
                provider = providerType,
                model = model,
                messages = listOf(AiMessage("user", "Hello! Respond with: Connected to ${providerType.displayName} successfully.")),
                maxTokens = 30,
                apiKey = apiKey
            )
            val res = generateResponse(testRequest)
            if (res.isSuccess) {
                Result.success(res.text.ifBlank { "Connection verified!" })
            } else {
                Result.failure(Exception(res.errorMessage ?: "Verification failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun buildJsonPayload(request: AiRequest, stream: Boolean): JSONObject {
        val root = JSONObject()
        root.put("model", request.model)
        root.put("stream", stream)
        root.put("temperature", request.temperature)
        root.put("max_tokens", request.maxTokens)

        val messagesArray = JSONArray()
        for (msg in request.messages) {
            val msgObj = JSONObject()
            msgObj.put("role", msg.role)

            if (!msg.imageBase64.isNullOrBlank()) {
                val contentArray = JSONArray()
                val textPart = JSONObject()
                textPart.put("type", "text")
                textPart.put("text", msg.content)
                contentArray.put(textPart)

                val imagePart = JSONObject()
                imagePart.put("type", "image_url")
                val imageUrlObj = JSONObject()
                val mime = msg.mimeType ?: "image/jpeg"
                imageUrlObj.put("url", "data:$mime;base64,${msg.imageBase64}")
                imagePart.put("image_url", imageUrlObj)
                contentArray.put(imagePart)

                msgObj.put("content", contentArray)
            } else {
                msgObj.put("content", msg.content)
            }
            messagesArray.put(msgObj)
        }
        root.put("messages", messagesArray)
        return root
    }

    private fun parseErrorBody(code: Int, body: String): String {
        return try {
            val json = JSONObject(body)
            val error = json.optJSONObject("error")
            val message = error?.optString("message", "") ?: body
            when (code) {
                401 -> "Authentication error (401): Invalid API Key."
                403 -> "Forbidden (403): You do not have permission or access to this model."
                429 -> "Rate limit reached (429): Too many requests or insufficient quota."
                else -> "HTTP $code: $message"
            }
        } catch (_: Exception) {
            when (code) {
                401 -> "Authentication error (401): Invalid API Key."
                429 -> "Rate limit exceeded (429)."
                else -> "HTTP Error $code: $body"
            }
        }
    }
}
