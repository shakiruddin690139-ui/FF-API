package com.example.ai.provider

import com.example.ai.model.AiProviderType
import com.example.ai.model.AiRequest
import com.example.ai.model.AiResponse
import com.example.ai.model.AiStreamEvent
import kotlinx.coroutines.flow.Flow

interface AiProvider {
    val providerType: AiProviderType
    suspend fun generateResponse(request: AiRequest): AiResponse
    suspend fun streamResponse(request: AiRequest): Flow<AiStreamEvent>
    suspend fun testConnectivity(apiKey: String, model: String): Result<String>
}
