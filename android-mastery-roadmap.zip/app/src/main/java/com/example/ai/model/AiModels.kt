package com.example.ai.model

enum class AiProviderType(
    val id: String,
    val displayName: String,
    val defaultModel: String,
    val models: List<String>
) {
    GROK(
        id = "GROK",
        displayName = "Grok (xAI)",
        defaultModel = "grok-2-latest",
        models = listOf("grok-2-latest", "grok-2", "grok-beta")
    ),
    OPENAI(
        id = "OPENAI",
        displayName = "OpenAI (ChatGPT)",
        defaultModel = "gpt-4o-mini",
        models = listOf("gpt-4o-mini", "gpt-4o", "gpt-4-turbo", "gpt-3.5-turbo")
    ),
    GEMINI(
        id = "GEMINI",
        displayName = "Google Gemini",
        defaultModel = "gemini-2.5-flash",
        models = listOf("gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-pro", "gemini-1.5-flash")
    );

    companion object {
        fun fromId(id: String): AiProviderType {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: GEMINI
        }
    }
}

data class AiMessage(
    val role: String, // "system", "user", "assistant"
    val content: String,
    val imageBase64: String? = null,
    val mimeType: String? = null
)

data class AiRequest(
    val provider: AiProviderType,
    val model: String,
    val messages: List<AiMessage>,
    val temperature: Float = 0.7f,
    val maxTokens: Int = 2048,
    val apiKey: String = ""
)

data class AiResponse(
    val text: String,
    val provider: AiProviderType,
    val model: String,
    val isSuccess: Boolean = true,
    val errorMessage: String? = null
)

sealed class AiStreamEvent {
    data class Chunk(val text: String) : AiStreamEvent()
    data class Completed(val fullText: String) : AiStreamEvent()
    data class Error(val error: String) : AiStreamEvent()
}
