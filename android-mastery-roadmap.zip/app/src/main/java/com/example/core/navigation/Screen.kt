package com.example.core.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MicNone
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    object Home : Screen("home", "Home", Icons.Filled.Home, Icons.Outlined.Home)
    object Chat : Screen("chat", "AI Chat", Icons.Filled.ChatBubble, Icons.Outlined.ChatBubbleOutline)
    object Voice : Screen("voice", "Voice", Icons.Filled.Mic, Icons.Outlined.MicNone)
    object Create : Screen("create", "Studio", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome)
    object History : Screen("history", "History", Icons.Filled.History, Icons.Outlined.History)
    object Settings : Screen("settings", "Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
    object Permissions : Screen("permissions", "Permissions", Icons.Filled.Settings, Icons.Outlined.Settings)
}

val BottomNavItems = listOf(
    Screen.Home,
    Screen.Chat,
    Screen.Voice,
    Screen.Create,
    Screen.History,
    Screen.Settings
)
