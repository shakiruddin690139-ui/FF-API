package com.example

import android.app.Application
import com.example.ai.provider.ProviderManager
import com.example.automation.commands.ActionExecutor
import com.example.automation.commands.ActionInterpreter
import com.example.core.security.KeyStoreHelper
import com.example.data.local.NexaDatabase
import com.example.data.preferences.UserPreferences
import com.example.media.video.VideoComposer

class NexaApplication : Application() {

    val database by lazy { NexaDatabase.getDatabase(this) }
    val userPreferences by lazy { UserPreferences(this) }
    val keyStoreHelper by lazy { KeyStoreHelper(this) }
    val providerManager by lazy { ProviderManager(keyStoreHelper) }
    val actionInterpreter by lazy { ActionInterpreter() }
    val actionExecutor by lazy { ActionExecutor(this) }
    val videoComposer by lazy { VideoComposer(this) }

    override fun onCreate() {
        super.onCreate()
    }
}
