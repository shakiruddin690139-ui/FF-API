package com.example.voice

sealed class VoiceState {
    object Idle : VoiceState()
    data class Listening(val partialText: String = "") : VoiceState()
    data class Processing(val promptText: String) : VoiceState()
    data class Speaking(val spokenText: String) : VoiceState()
    data class Error(val message: String) : VoiceState()
}
