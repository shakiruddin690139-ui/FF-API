package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_projects")
data class ProjectEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val type: String, // "VOICE_TO_VIDEO", "IMAGE_TO_VIDEO", "ANIMATED_TEXT"
    val aspectRatio: String, // "9:16", "16:9", "1:1"
    val scriptText: String,
    val textAnimation: String,
    val mediaUrisJson: String,
    val durationSeconds: Int,
    val createdAt: Long
)
