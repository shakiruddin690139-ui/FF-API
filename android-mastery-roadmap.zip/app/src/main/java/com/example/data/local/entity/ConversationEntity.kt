package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val provider: String,
    val model: String,
    val createdAt: Long,
    val updatedAt: Long,
    val summary: String = ""
)
