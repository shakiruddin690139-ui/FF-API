package com.example.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "nexa_preferences")

class UserPreferences(private val context: Context) {

    companion object {
        val SELECTED_PROVIDER = stringPreferencesKey("selected_provider")
        val GROK_MODEL = stringPreferencesKey("grok_model")
        val OPENAI_MODEL = stringPreferencesKey("openai_model")
        val GEMINI_MODEL = stringPreferencesKey("gemini_model")
        val VOICE_LANGUAGE = stringPreferencesKey("voice_language")
        val SPEECH_SPEED = floatPreferencesKey("speech_speed")
        val CONTINUOUS_LISTENING = booleanPreferencesKey("continuous_listening")
        val AUTO_SPEAK_RESPONSE = booleanPreferencesKey("auto_speak_response")
        val HAPTIC_FEEDBACK = booleanPreferencesKey("haptic_feedback")
        val SOUND_EFFECTS = booleanPreferencesKey("sound_effects")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val FOLLOW_SYSTEM_THEME = booleanPreferencesKey("follow_system_theme")
    }

    val selectedProviderFlow: Flow<String> = context.dataStore.data.map {
        it[SELECTED_PROVIDER] ?: "GEMINI"
    }

    val grokModelFlow: Flow<String> = context.dataStore.data.map {
        it[GROK_MODEL] ?: "grok-2-latest"
    }

    val openAiModelFlow: Flow<String> = context.dataStore.data.map {
        it[OPENAI_MODEL] ?: "gpt-4o-mini"
    }

    val geminiModelFlow: Flow<String> = context.dataStore.data.map {
        it[GEMINI_MODEL] ?: "gemini-2.5-flash"
    }

    val voiceLanguageFlow: Flow<String> = context.dataStore.data.map {
        it[VOICE_LANGUAGE] ?: "en-US"
    }

    val speechSpeedFlow: Flow<Float> = context.dataStore.data.map {
        it[SPEECH_SPEED] ?: 1.0f
    }

    val continuousListeningFlow: Flow<Boolean> = context.dataStore.data.map {
        it[CONTINUOUS_LISTENING] ?: false
    }

    val autoSpeakResponseFlow: Flow<Boolean> = context.dataStore.data.map {
        it[AUTO_SPEAK_RESPONSE] ?: true
    }

    val hapticFeedbackFlow: Flow<Boolean> = context.dataStore.data.map {
        it[HAPTIC_FEEDBACK] ?: true
    }

    val soundEffectsFlow: Flow<Boolean> = context.dataStore.data.map {
        it[SOUND_EFFECTS] ?: false
    }

    val darkThemeFlow: Flow<Boolean> = context.dataStore.data.map {
        it[DARK_THEME] ?: false
    }

    val followSystemThemeFlow: Flow<Boolean> = context.dataStore.data.map {
        it[FOLLOW_SYSTEM_THEME] ?: true
    }

    suspend fun setSelectedProvider(provider: String) {
        context.dataStore.edit { it[SELECTED_PROVIDER] = provider }
    }

    suspend fun setGrokModel(model: String) {
        context.dataStore.edit { it[GROK_MODEL] = model }
    }

    suspend fun setOpenAiModel(model: String) {
        context.dataStore.edit { it[OPENAI_MODEL] = model }
    }

    suspend fun setGeminiModel(model: String) {
        context.dataStore.edit { it[GEMINI_MODEL] = model }
    }

    suspend fun setVoiceLanguage(lang: String) {
        context.dataStore.edit { it[VOICE_LANGUAGE] = lang }
    }

    suspend fun setSpeechSpeed(speed: Float) {
        context.dataStore.edit { it[SPEECH_SPEED] = speed }
    }

    suspend fun setContinuousListening(enabled: Boolean) {
        context.dataStore.edit { it[CONTINUOUS_LISTENING] = enabled }
    }

    suspend fun setAutoSpeakResponse(enabled: Boolean) {
        context.dataStore.edit { it[AUTO_SPEAK_RESPONSE] = enabled }
    }

    suspend fun setHapticFeedback(enabled: Boolean) {
        context.dataStore.edit { it[HAPTIC_FEEDBACK] = enabled }
    }

    suspend fun setSoundEffects(enabled: Boolean) {
        context.dataStore.edit { it[SOUND_EFFECTS] = enabled }
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.dataStore.edit { it[DARK_THEME] = enabled }
    }

    suspend fun setFollowSystemTheme(enabled: Boolean) {
        context.dataStore.edit { it[FOLLOW_SYSTEM_THEME] = enabled }
    }
}
