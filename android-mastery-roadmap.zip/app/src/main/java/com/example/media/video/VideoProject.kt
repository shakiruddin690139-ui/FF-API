package com.example.media.video

import java.util.UUID

enum class VideoAspectRatio(val label: String, val widthRatio: Float, val heightRatio: Float) {
    VERTICAL_9_16("9:16 Shorts / Reels", 9f, 16f),
    LANDSCAPE_16_9("16:9 YouTube", 16f, 9f),
    SQUARE_1_1("1:1 Square", 1f, 1f)
}

enum class TextAnimationType(val displayName: String, val description: String) {
    POP("Pop Dynamic", "Bouncy scale emphasis for viral short-form retention"),
    TYPEWRITER("Typewriter", "Retro terminal character-by-character reveal"),
    WORD_BY_WORD("Word-by-Word", "Modern TikTok & Reels karaoke highlighting"),
    SLIDE_UP("Slide Up", "Sleek bottom-up motion reveal"),
    SLIDE_LEFT("Slide Left", "Dynamic kinetic horizontal slide"),
    FADE_IN("Fade In", "Smooth cinematic alpha transition"),
    BOUNCE("Bounce Accent", "Energetic playful keyframe bounce"),
    SCALE_IN("Scale In", "Center outward expansion zoom"),
    SUBTITLE_REVEAL("Subtitle Reveal", "Minimalist dual-line broadcast captioning")
}

data class TimedCaption(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val startSecond: Float,
    val endSecond: Float
)

data class VideoProjectState(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "NEXA AI Short",
    val scriptText: String = "Transform your ideas into stunning short-form videos with NEXA AI.",
    val timedCaptions: List<TimedCaption> = listOf(
        TimedCaption(text = "Welcome to NEXA AI", startSecond = 0f, endSecond = 2.5f),
        TimedCaption(text = "Your Personal Android Assistant", startSecond = 2.5f, endSecond = 6.0f),
        TimedCaption(text = "Create Viral Shorts In Seconds!", startSecond = 6.0f, endSecond = 10.0f)
    ),
    val aspectRatio: VideoAspectRatio = VideoAspectRatio.VERTICAL_9_16,
    val animationType: TextAnimationType = TextAnimationType.POP,
    val backgroundThemeIndex: Int = 0,
    val durationSeconds: Int = 10,
    val mediaUris: List<String> = emptyList(),
    val isRendering: Boolean = false,
    val renderProgress: Float = 0f,
    val renderedFilePath: String? = null
)
