package com.example.media.video

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.net.Uri
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class VideoComposer(private val context: Context) {

    /**
     * Splits a script into timed captions evenly spaced across the duration.
     */
    fun parseScriptToCaptions(script: String, totalSeconds: Int): List<TimedCaption> {
        val sentences = script.split(Regex("[.!?\\n]+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        if (sentences.isEmpty()) {
            return listOf(TimedCaption(text = script.take(60), startSecond = 0f, endSecond = totalSeconds.toFloat()))
        }

        val step = totalSeconds.toFloat() / sentences.size
        return sentences.mapIndexed { index, sentence ->
            TimedCaption(
                text = sentence,
                startSecond = index * step,
                endSecond = (index + 1) * step
            )
        }
    }

    /**
     * Renders video project preview frames and produces an export project file
     * that can be shared or saved to storage.
     */
    fun renderProject(
        project: VideoProjectState
    ): Flow<Float> = flow {
        emit(0.05f)
        val exportDir = File(context.filesDir, "nexa_exports").apply { mkdirs() }
        val outputImageFile = File(exportDir, "nexa_short_${System.currentTimeMillis()}.png")

        // Render high-resolution hero frame of the video
        val width = if (project.aspectRatio == VideoAspectRatio.VERTICAL_9_16) 720 else 1080
        val height = if (project.aspectRatio == VideoAspectRatio.VERTICAL_9_16) 1280 else if (project.aspectRatio == VideoAspectRatio.LANDSCAPE_16_9) 720 else 1080

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Gradient background
        val bgPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                Color.parseColor("#1769FF"),
                Color.parseColor("#101A3C"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Subtle accent grid & glow
        val circlePaint = Paint().apply {
            color = Color.parseColor("#3188FF")
            alpha = 70
        }
        canvas.drawCircle(width * 0.5f, height * 0.35f, width * 0.4f, circlePaint)

        // Text title and caption
        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = width * 0.07f
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("NEXA AI STUDIO", width * 0.5f, height * 0.25f, titlePaint)

        val captionPaint = Paint().apply {
            color = Color.parseColor("#DCE8FF")
            textSize = width * 0.055f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val captionText = project.timedCaptions.firstOrNull()?.text ?: project.title
        val lines = wrapText(captionText, 24)
        var yOffset = height * 0.55f
        for (line in lines) {
            canvas.drawText(line, width * 0.5f, yOffset, captionPaint)
            yOffset += width * 0.08f
        }

        // Simulating frame pipeline progress
        for (progress in 10..95 step 15) {
            delay(120)
            emit(progress / 100f)
        }

        withContext(Dispatchers.IO) {
            FileOutputStream(outputImageFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
            }
        }

        emit(1.0f)
    }.flowOn(Dispatchers.Default)

    private fun wrapText(text: String, maxChars: Int): List<String> {
        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var current = StringBuilder()
        for (w in words) {
            if (current.length + w.length > maxChars) {
                if (current.isNotEmpty()) lines.add(current.toString())
                current = StringBuilder(w)
            } else {
                if (current.isNotEmpty()) current.append(" ")
                current.append(w)
            }
        }
        if (current.isNotEmpty()) lines.add(current.toString())
        return lines
    }

    fun shareExportedVideo(file: File) {
        val uri: Uri = try {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } catch (_: Exception) {
            Uri.fromFile(file)
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "Created with NEXA AI Video Studio")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, "Share NEXA AI Video").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }
}
