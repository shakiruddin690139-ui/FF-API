package com.example.automation.commands

import java.util.Locale

class ActionInterpreter {

    fun interpret(input: String): DeviceAction? {
        val lower = input.trim().lowercase(Locale.ROOT)
        val clean = lower

        // 1. YouTube specific commands
        if (lower.contains("search youtube for ")) {
            val idx = lower.indexOf("search youtube for ") + "search youtube for ".length
            val query = input.trim().substring(idx).trim()
            if (query.isNotBlank()) return DeviceAction.SearchYouTube(query)
        }

        if (lower.contains("youtube pe search karo ")) {
            val idx = lower.indexOf("youtube pe search karo ") + "youtube pe search karo ".length
            val query = input.trim().substring(idx).trim()
            if (query.isNotBlank()) return DeviceAction.SearchYouTube(query)
        }

        if (lower.startsWith("play ") && (lower.contains("shakir") || lower.contains("video") || lower.contains("gameplay") || lower.contains("song"))) {
            val query = input.trim().substring(5).replace("(?i) on youtube".toRegex(), "").trim()
            return DeviceAction.PlayYouTubeVideo(query)
        }

        if (lower.contains("youtube pe chalao") || lower.contains("youtube par search")) {
            val query = lower.replace("youtube pe chalao", "").replace("youtube par search", "").trim()
            if (query.isNotBlank()) return DeviceAction.SearchYouTube(query)
        }

        if (lower == "open youtube" || lower == "youtube kholo" || lower == "youtube open karo" || lower == "launch youtube") {
            return DeviceAction.OpenApplication("YouTube", "com.google.android.youtube")
        }

        // 2. Browser & Web Navigation
        if (clean.startsWith("open ") && (clean.contains(".com") || clean.contains(".org") || clean.contains(".net") || clean.contains(".io") || clean.contains(".ai"))) {
            var url = clean.removePrefix("open ").trim()
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "https://$url"
            }
            return DeviceAction.OpenWebsite(url)
        }

        if (clean.contains("open chatgpt") || clean.contains("chatgpt in my browser")) {
            return DeviceAction.OpenWebsite("https://chatgpt.com")
        }

        if (clean.contains("open google") || clean == "open google.com") {
            return DeviceAction.OpenWebsite("https://google.com")
        }

        // 3. Web Search
        if (clean.startsWith("search the web for ") || clean.startsWith("search for ") || clean.startsWith("google search ")) {
            val query = clean.removePrefix("search the web for ")
                .removePrefix("search for ")
                .removePrefix("google search ")
                .trim()
            if (query.isNotBlank()) return DeviceAction.SearchWeb(query)
        }

        // 4. System Settings
        if (clean.contains("bluetooth setting") || clean.contains("bluetooth kholo") || clean.contains("open bluetooth")) {
            return DeviceAction.OpenSystemSettings(SettingType.BLUETOOTH)
        }
        if (clean.contains("wifi setting") || clean.contains("wi-fi setting") || clean.contains("open wifi") || clean.contains("open wi-fi")) {
            return DeviceAction.OpenSystemSettings(SettingType.WIFI)
        }
        if (clean.contains("sound setting") || clean.contains("audio setting")) {
            return DeviceAction.OpenSystemSettings(SettingType.SOUND)
        }
        if (clean.contains("display setting") || clean.contains("screen setting")) {
            return DeviceAction.OpenSystemSettings(SettingType.DISPLAY)
        }
        if (clean.contains("accessibility setting") || clean.contains("accessibility options")) {
            return DeviceAction.OpenSystemSettings(SettingType.ACCESSIBILITY)
        }

        // 5. App Launching
        if (clean == "open chrome" || clean == "chrome kholo" || clean == "launch chrome") {
            return DeviceAction.OpenApplication("Chrome", "com.android.chrome")
        }
        if (clean == "open calculator" || clean == "calculator kholo" || clean == "open the calculator") {
            return DeviceAction.OpenApplication("Calculator", null)
        }
        if (clean == "open camera" || clean == "camera kholo") {
            return DeviceAction.OpenApplication("Camera", null)
        }
        if (clean == "open settings" || clean == "settings kholo") {
            return DeviceAction.OpenSystemSettings(SettingType.GENERAL)
        }
        if (clean.startsWith("open app ") || clean.startsWith("launch ")) {
            val app = clean.removePrefix("open app ").removePrefix("launch ").trim()
            if (app.isNotBlank()) return DeviceAction.OpenApplication(app, null)
        }

        // 6. Media Control
        if (clean.contains("volume up") || clean.contains("increase volume") || clean.contains("awaaz badhao")) {
            return DeviceAction.MediaControl(MediaCommand.VOLUME_UP)
        }
        if (clean.contains("volume down") || clean.contains("decrease volume") || clean.contains("awaaz kam karo")) {
            return DeviceAction.MediaControl(MediaCommand.VOLUME_DOWN)
        }
        if (clean.contains("pause video") || clean.contains("pause music") || clean.contains("pause playback")) {
            return DeviceAction.MediaControl(MediaCommand.PLAY_PAUSE)
        }

        // 7. Screen Understanding
        if (clean.contains("what is on my screen") || clean.contains("what is visible on the current screen") || clean.contains("explain this screen")) {
            return DeviceAction.CaptureScreenContext("Screen inspection requested by user")
        }

        // 8. Video creation studio commands
        if (clean.contains("create an animated text video") || clean.contains("animated text video") || clean.contains("generate a video script")) {
            return DeviceAction.GenerateVideoProject("ANIMATED_TEXT", input)
        }

        return null
    }
}
