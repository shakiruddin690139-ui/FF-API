package com.example.automation.commands

sealed class DeviceAction(val title: String, val category: String) {
    data class OpenApplication(
        val appName: String,
        val preferredPackage: String? = null
    ) : DeviceAction("Open App", "App Launch")

    data class OpenWebsite(
        val url: String
    ) : DeviceAction("Open Website", "Web Navigation")

    data class SearchWeb(
        val query: String
    ) : DeviceAction("Search Web", "Search")

    data class SearchYouTube(
        val query: String
    ) : DeviceAction("Search YouTube", "YouTube")

    data class PlayYouTubeVideo(
        val query: String
    ) : DeviceAction("Play YouTube", "YouTube Playback")

    data class OpenSystemSettings(
        val settingType: SettingType
    ) : DeviceAction("Open Settings", "System")

    data class MediaControl(
        val command: MediaCommand
    ) : DeviceAction("Media Control", "System Media")

    data class CopyText(
        val text: String
    ) : DeviceAction("Copy to Clipboard", "Productivity")

    data class CreateLocalReminder(
        val reminderTitle: String,
        val timeDescription: String? = null
    ) : DeviceAction("Create Reminder", "Productivity")

    data class CaptureScreenContext(
        val intentDescription: String = "Explain screen"
    ) : DeviceAction("Screen Understanding", "Vision")

    data class AccessibilityAssist(
        val actionType: String,
        val targetText: String = ""
    ) : DeviceAction("Accessibility Action", "Assisted Control")

    data class GenerateVideoProject(
        val projectType: String,
        val prompt: String
    ) : DeviceAction("Launch Video Studio", "Studio")
}

enum class SettingType {
    BLUETOOTH,
    WIFI,
    SOUND,
    DISPLAY,
    ACCESSIBILITY,
    GENERAL
}

enum class MediaCommand {
    PLAY_PAUSE,
    NEXT,
    PREVIOUS,
    VOLUME_UP,
    VOLUME_DOWN
}

data class ActionResult(
    val isSuccess: Boolean,
    val feedbackMessage: String,
    val actionType: String
)
