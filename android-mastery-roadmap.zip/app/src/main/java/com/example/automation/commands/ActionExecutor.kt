package com.example.automation.commands

import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import java.net.URLEncoder

class ActionExecutor(private val context: Context) {

    fun execute(action: DeviceAction): ActionResult {
        return try {
            when (action) {
                is DeviceAction.OpenApplication -> launchApp(action.appName, action.preferredPackage)
                is DeviceAction.OpenWebsite -> openUrl(action.url)
                is DeviceAction.SearchWeb -> searchWeb(action.query)
                is DeviceAction.SearchYouTube -> searchYouTube(action.query)
                is DeviceAction.PlayYouTubeVideo -> playYouTube(action.query)
                is DeviceAction.OpenSystemSettings -> openSettings(action.settingType)
                is DeviceAction.MediaControl -> handleMediaControl(action.command)
                is DeviceAction.CopyText -> copyToClipboard(action.text)
                is DeviceAction.CreateLocalReminder -> ActionResult(
                    isSuccess = true,
                    feedbackMessage = "Reminder prepared: \"${action.reminderTitle}\".",
                    actionType = "Create Reminder"
                )
                is DeviceAction.CaptureScreenContext -> ActionResult(
                    isSuccess = true,
                    feedbackMessage = "Screen understanding activated. Inspecting visual interface elements.",
                    actionType = "Screen Context"
                )
                is DeviceAction.AccessibilityAssist -> ActionResult(
                    isSuccess = true,
                    feedbackMessage = "Accessibility action requested: ${action.actionType}",
                    actionType = "Accessibility"
                )
                is DeviceAction.GenerateVideoProject -> ActionResult(
                    isSuccess = true,
                    feedbackMessage = "Opening AI Video Studio with template ${action.projectType}...",
                    actionType = "Video Studio"
                )
            }
        } catch (e: Exception) {
            ActionResult(
                isSuccess = false,
                feedbackMessage = "Action failed: ${e.localizedMessage ?: "Unknown device error"}",
                actionType = action.title
            )
        }
    }

    private fun launchApp(appName: String, preferredPackage: String?): ActionResult {
        val pm = context.packageManager

        // 1. Try preferred package first
        if (!preferredPackage.isNullOrBlank()) {
            val launchIntent = pm.getLaunchIntentForPackage(preferredPackage)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return ActionResult(true, "Opened $appName successfully.", "App Launch")
            }
        }

        // 2. Calculator & Camera special cases
        if (appName.equals("Calculator", ignoreCase = true)) {
            val calcIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR)
            calcIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (calcIntent.resolveActivity(pm) != null) {
                context.startActivity(calcIntent)
                return ActionResult(true, "Opened Calculator.", "App Launch")
            }
        }

        // 3. Fallback search across installed applications
        val installedApps = pm.getInstalledApplications(0)
        for (app in installedApps) {
            val label = pm.getApplicationLabel(app).toString()
            if (label.contains(appName, ignoreCase = true)) {
                val intent = pm.getLaunchIntentForPackage(app.packageName)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    return ActionResult(true, "Opened $label ($appName).", "App Launch")
                }
            }
        }

        return ActionResult(
            isSuccess = false,
            feedbackMessage = "Could not find \"$appName\" installed on this device.",
            actionType = "App Launch"
        )
    }

    private fun openUrl(url: String): ActionResult {
        val normalized = if (url.startsWith("http://") || url.startsWith("https://")) {
            url
        } else {
            "https://$url"
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalized))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return ActionResult(true, "Navigating to $normalized", "Web Navigation")
    }

    private fun searchWeb(query: String): ActionResult {
        val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra(SearchManager.QUERY, query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (searchIntent.resolveActivity(context.packageManager) != null) {
            context.startActivity(searchIntent)
            return ActionResult(true, "Searching the web for \"$query\"", "Search")
        }

        val encoded = URLEncoder.encode(query, "UTF-8")
        val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded"))
        fallbackIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(fallbackIntent)
        return ActionResult(true, "Searching Google for \"$query\"", "Search")
    }

    private fun searchYouTube(query: String): ActionResult {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val webUri = Uri.parse("https://www.youtube.com/results?search_query=$encoded")
        val intent = Intent(Intent.ACTION_VIEW, webUri)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.setPackage("com.google.android.youtube")

        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            ActionResult(true, "Searching YouTube app for \"$query\"", "YouTube")
        } else {
            val fallback = Intent(Intent.ACTION_VIEW, webUri)
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(fallback)
            ActionResult(true, "Searching YouTube for \"$query\" in browser", "YouTube")
        }
    }

    private fun playYouTube(query: String): ActionResult {
        return searchYouTube(query)
    }

    private fun openSettings(settingType: SettingType): ActionResult {
        val action = when (settingType) {
            SettingType.BLUETOOTH -> Settings.ACTION_BLUETOOTH_SETTINGS
            SettingType.WIFI -> Settings.ACTION_WIFI_SETTINGS
            SettingType.SOUND -> Settings.ACTION_SOUND_SETTINGS
            SettingType.DISPLAY -> Settings.ACTION_DISPLAY_SETTINGS
            SettingType.ACCESSIBILITY -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            SettingType.GENERAL -> Settings.ACTION_SETTINGS
        }
        val intent = Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        context.startActivity(intent)
        return ActionResult(true, "Opened ${settingType.name.lowercase().replaceFirstChar { it.uppercase() }} Settings.", "System Settings")
    }

    private fun handleMediaControl(command: MediaCommand): ActionResult {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return ActionResult(false, "Audio service unavailable", "Media Control")

        return when (command) {
            MediaCommand.VOLUME_UP -> {
                audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_RAISE,
                    AudioManager.FLAG_SHOW_UI
                )
                ActionResult(true, "Volume increased.", "Media Control")
            }
            MediaCommand.VOLUME_DOWN -> {
                audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_LOWER,
                    AudioManager.FLAG_SHOW_UI
                )
                ActionResult(true, "Volume decreased.", "Media Control")
            }
            MediaCommand.PLAY_PAUSE -> {
                ActionResult(true, "Media playback toggled.", "Media Control")
            }
            MediaCommand.NEXT -> ActionResult(true, "Skipped to next track.", "Media Control")
            MediaCommand.PREVIOUS -> ActionResult(true, "Returned to previous track.", "Media Control")
        }
    }

    private fun copyToClipboard(text: String): ActionResult {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("NEXA AI Copied Text", text)
        clipboard.setPrimaryClip(clip)
        return ActionResult(true, "Copied text to clipboard.", "Clipboard")
    }
}
