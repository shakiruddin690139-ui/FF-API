package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.core.navigation.NexaBottomNavigationBar
import com.example.core.navigation.Screen
import com.example.ui.NexaViewModel
import com.example.ui.chat.ChatScreen
import com.example.ui.create.CreateStudioScreen
import com.example.ui.history.HistoryScreen
import com.example.ui.home.HomeScreen
import com.example.ui.permissions.PermissionsCenterScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.voice.VoiceAssistantScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: NexaViewModel = viewModel()
            val followSystemTheme by viewModel.followSystemThemeFlow.collectAsState()
            val isDarkConfig by viewModel.darkThemeFlow.collectAsState()
            val isDark = if (followSystemTheme) isSystemInDarkTheme() else isDarkConfig

            MyApplicationTheme(darkTheme = isDark) {
                NexaMainApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun NexaMainApp(viewModel: NexaViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Home.route

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            if (currentRoute != Screen.Permissions.route) {
                NexaBottomNavigationBar(
                    currentRoute = currentRoute,
                    onNavigate = { route ->
                        if (route != currentRoute) {
                            navController.navigate(route) {
                                popUpTo(Screen.Home.route) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route,
                modifier = Modifier.fillMaxSize()
            ) {
                composable(Screen.Home.route) {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigate = { route -> navController.navigate(route) }
                    )
                }

                composable(Screen.Chat.route) {
                    ChatScreen(
                        viewModel = viewModel,
                        onNavigateToVoice = { navController.navigate(Screen.Voice.route) }
                    )
                }

                composable(Screen.Voice.route) {
                    VoiceAssistantScreen(
                        viewModel = viewModel,
                        onNavigateToChat = { navController.navigate(Screen.Chat.route) }
                    )
                }

                composable(Screen.Create.route) {
                    CreateStudioScreen(viewModel = viewModel)
                }

                composable(Screen.History.route) {
                    HistoryScreen(
                        viewModel = viewModel,
                        onNavigateToChat = { navController.navigate(Screen.Chat.route) }
                    )
                }

                composable(Screen.Settings.route) {
                    SettingsScreen(
                        viewModel = viewModel,
                        onNavigateToPermissions = { navController.navigate(Screen.Permissions.route) }
                    )
                }

                composable(Screen.Permissions.route) {
                    PermissionsCenterScreen(
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}
